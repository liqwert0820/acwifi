# AutoWifi · 校园网自动登录

一个纯原生 Android（Java，无第三方运行时依赖）的校园网 Web 门户自动登录应用。
连上校园 WiFi 后自动完成网页认证，支持接口表单提交与后台 WebView 静默登录两种方式，
并对国内常见校园网关产品族做了自动识别与适配。

> 仅供本人账号在合规前提下使用，请遵守所在学校的网络管理规定。

## 功能

- **启动自检页**：纯代码绘制，五步体检（日志/配置/布局解析/加密/权限）逐条展示 `✓ 耗时ms` 或 `✗ 异常链`，任何一步失败都不闪退
- 连上指定 SSID 后自动触发登录；后台前台服务轮询 + 网络回调双触发
- 两种登录方式：
  - **接口表单提交**：简单门户直接 POST/GET 表单，可配置字段名、隐藏字段、成功关键词
  - **网页静默登录**：后台不可见 WebView 打开认证页，注入脚本自动勾选协议、填写账号密码、点击登录；带加密签名/摘要的门户由页面自身 JS 完成计算
- 主流产品族识别：GiWiFi/GPortal、锐捷 SRun、深澜 SDR、华为 ePortal/HGPortal、H3C iMC、Dr.COM/城市热点 Web 门户、通用 Web 表单
- 登录后延迟校验（默认 6 秒可调）+ 失败自动重试，避免门户放行延迟导致误判
- 内置浏览器抓包：Hook fetch/XHR、监听表单提交，识别登录请求并回填配置
- 一键诊断：外网探测、认证页解析、配置摘要、真实登录请求与响应、二次探测、结论建议
- 完整运行日志（可导出/分享到「下载/AutoWifi」），主界面常驻实时输出栏
- 密码使用 AndroidKeyStore AES-GCM 加密后存入本机 SharedPreferences，不明文落盘
- 配置导入/导出（剪贴板 JSON）、登录历史、开机自启、电池优化白名单引导、系统网络建议自动连接
- 可更换背景：内置渐变或从相册选图
- 关于页：版本信息、项目简介、Telegram 频道入口与链接复制
- 主界面安全模式：布局意外解析失败时进入纯代码兜底页，展示逐层异常链

## 模块结构

包名 `com.school.autowifi`，源码位于 `app/src/main/java/com/school/autowifi/`：

| 文件 | 职责 |
|---|---|
| `SplashActivity.java` | 启动自检页：纯代码 UI，五步体检与异常展示，桌面入口 |
| `MainActivity.java` | 主界面：标签页、表单、登录分派、延迟校验与重试、日志/诊断/配置、背景设置、启动兜底与安全模式 |
| `AboutActivity.java` | 关于页：版本、简介、Telegram 频道打开/复制 |
| `WifiMonitorService.java` | 前台监控服务：轮询与网络回调、冷却、通知栏操作、后台登录与校验 |
| `NetHelper.java` | 网络工具：外网探测、门户探测与表单解析、接口登录、响应判定、状态判断、诊断报告 |
| `WebLoginEngine.java` | 网页静默登录引擎：后台 WebView、分阶段注入脚本、延迟后复查、超时回收 |
| `PortalFamily.java` | 门户产品族识别与建议登录方式 |
| `CaptureActivity.java` | 内置抓包浏览器：JS Hook、表单监听、请求打分回填 |
| `Config.java` | SharedPreferences 读写（密码字段透明加解密） |
| `Crypto.java` | AndroidKeyStore AES-GCM 加解密 |
| `History.java` | 最近登录记录（内存 + 持久化） |
| `LogStore.java` | 内存环形日志 + 文件追加，提供全量导出与尾部输出 |
| `WifiSuggestion.java` | 系统网络建议（WifiNetworkSuggestion），引导自动连接 |
| `App.java` | Application：崩溃捕获并写入 `crash.txt`，初始化日志 |
| `BootReceiver.java` | 开机自启广播 |

资源：`res/layout`（主界面、关于页；启动页不用 XML）、`res/values`（颜色/样式/文案）、`res/drawable`（卡片与背景）、`res/mipmap-*`（图标）。

## 构建环境

- JDK 17
- Android SDK Platform 34、Build Tools 34.0.0、Platform-tools
- Gradle 8.7、Android Gradle Plugin 8.5.0
- minSdk 26（Android 8.0），targetSdk / compileSdk 34
- 无第三方依赖，无需联网拉取 Maven 库即可编译

## 构建步骤

1. 复制 `local.properties.example` 为 `local.properties`，把 `sdk.dir` 改成本机 Android SDK 绝对路径。
2. Android Studio 打开本目录同步；或命令行：

   ```bash
   ./gradlew assembleDebug
   ```

   产物在 `app/build/outputs/apk/debug/app-debug.apk`。

3. 调试签名为 Android Debug 证书；发布前请自行配置 release 签名。

## 适配范围与边界

- 仅适用 **Web 页面认证型**门户；不支持、也无法在普通应用内复刻：
  - 专用客户端私有协议（锐捷/深澜/Dr.COM 私有端口登录）
  - 802.1X 企业认证
  - 短信 / 图形 / 滑块验证码（需人工一次）
- Android 系统限制：应用不能静默切换 WiFi，只能通过系统网络建议让用户确认后自动连接。
- 产品族识别基于 URL 与页面特征，学校后台改版后可能需要补充规则；动态渲染页面优先走网页静默登录。

## 故障排查

- 启动自检页某步红叉：页面已显示逐层 `Caused by`，点「复制错误详情」即可反馈。
- 主界面异常：自动进入安全模式并显示异常链。
- 需要更底层日志：`adb logcat -v threadtime | grep -E "AndroidRuntime|com.school.autowifi"`。

> 布局调试提示：XML 中每个控件必须自带宽高，或由 style 提供。漏写 `android:layout_width` 时，真机 inflate 会抛
> `UnsupportedOperationException: Binary XML file line #NN: You must supply a layout_width attribute`。

## 免责声明

本项目按「现状」提供，不附带任何明示或暗示担保。使用者需确保行为符合当地法律法规与所在学校网络规定；因使用本应用产生的账号、网络或合规问题，由使用者自行承担。

## 许可证

[MIT License](LICENSE)
