package com.school.autowifi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public class WifiMonitorService extends Service {

    public static final String ACTION_LOGIN = "com.school.autowifi.ACTION_LOGIN";
    public static final String ACTION_STOP = "com.school.autowifi.ACTION_STOP";

    private static final String CH_ID = "wifi_monitor";
    private static final long COOLDOWN = 30000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Config cfg;
    private long lastLoginAttempt = 0;
    private String lastStatus = "监控中";
    private ConnectivityManager.NetworkCallback netCb;

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            check();
            int sec = cfg == null ? 5 : cfg.getInt(Config.K_INTERVAL, 5);
            if (sec < 3) sec = 3;
            handler.postDelayed(this, sec * 1000L);
        }
    };

    private final Runnable oneShot = this::check;

    @Override
    public void onCreate() {
        super.onCreate();
        cfg = new Config(this);
        try {
            createChannel();
            startForeground(1, buildNotification(lastStatus));
        } catch (Throwable t) {
            lastStatus = "前台服务启动异常：" + t.getClass().getSimpleName();
        }
        registerNetCallback();
        handler.post(poll);
    }

    private void registerNetCallback() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities nc) {
                    if (nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                        lastStatus = "已联网，无需登录";
                        notifyStatus(lastStatus);
                    } else {
                        handler.post(oneShot);
                    }
                }

                @Override
                public void onAvailable(Network network) {
                    handler.post(oneShot);
                }
            };
            cm.registerDefaultNetworkCallback(netCb);
        } catch (Throwable ignored) { }
    }

    private void check() {
        if (cfg == null || !cfg.isMonitoring()) {
            stopSelf();
            return;
        }
        String target = cfg.get(Config.K_SSID, "");
        String current = NetHelper.currentSsid(this);
        if (target.isEmpty() || !target.equals(current)) return;

        if (NetHelper.isNetworkValidated(this)) {
            if (!"已联网，无需登录".equals(lastStatus)) {
                lastStatus = "已联网，无需登录";
                notifyStatus(lastStatus);
            }
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastLoginAttempt < COOLDOWN) return;
        lastLoginAttempt = now;
        LogStore.add("MON", "触发自动登录  ssid=" + current + "  冷却结束");
        doLoginNow();
    }

    private void doLoginNow() {
        String mode = cfg.get(Config.K_MODE, "auto");
        if (!"http".equals(mode)) {
            // 优先网页静默登录（能处理带加密签名的门户）
            WebLoginEngine.login(this, cfg, (ok, detail) -> {
                if (ok) {
                    markOk(detail);
                } else if ("auto".equals(mode)) {
                    LogStore.add("MON", "网页登录失败，回退接口提交：" + detail);
                    httpLoginNow("回退");
                } else {
                    markFail(detail);
                }
            });
        } else {
            httpLoginNow("接口");
        }
    }

    private void httpLoginNow(String tag) {
        NetHelper.doLogin(this, cfg, (ok, msg) -> {
            if (!ok) {
                markFail(msg);
                return;
            }
            int delay = Math.max(3, cfg.getInt(Config.K_DELAY, 6));
            int retry = Math.max(0, cfg.getInt(Config.K_RETRY, 2));
            LogStore.add("WAIT", "接口登录已提交，等待 " + delay + " 秒再校验…");
            handler.postDelayed(() -> verifyLoop(msg, 0, delay, retry), delay * 1000L);
        });
    }

    /** 后台监控里的延迟校验：失败按配置重试，每次重试前同样等待 */
    private void verifyLoop(String loginMsg, int attempt, int delay, int retry) {
        NetHelper.verifyAccess(this, (online, vmsg) -> {
            if (online || attempt >= retry) {
                if (online) markOk(loginMsg + "；已联网：" + vmsg);
                else markFail("登录已提交但校验未通过：" + vmsg);
                return;
            }
            int next = attempt + 1;
            LogStore.add("WAIT", "校验未通过，" + delay + " 秒后重试 " + next + "/" + retry);
            handler.postDelayed(() -> verifyLoop(loginMsg, next, delay, retry), delay * 1000L);
        });
    }

    private void markOk(String msg) {
        if (cfg == null) return;
        cfg.setInt(Config.K_OK_COUNT, cfg.getInt(Config.K_OK_COUNT, 0) + 1);
        lastStatus = "✅ " + msg;
        cfg.set(Config.K_LAST_RESULT, lastStatus);
        History.add(this, true, msg);
        notifyStatus(lastStatus);
    }

    private void markFail(String msg) {
        if (cfg == null) return;
        lastStatus = "❌ " + msg;
        cfg.set(Config.K_LAST_RESULT, lastStatus);
        History.add(this, false, msg);
        notifyStatus(lastStatus);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            if (cfg != null) cfg.setMonitoring(false);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_LOGIN.equals(action)) {
            handler.post(() -> {
                lastLoginAttempt = 0;
                doLoginNow();
            });
            return START_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(poll);
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && netCb != null) cm.unregisterNetworkCallback(netCb);
        } catch (Throwable ignored) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CH_ID, "校园网监控", NotificationManager.IMPORTANCE_LOW);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent piOpen = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent login = new Intent(this, WifiMonitorService.class).setAction(ACTION_LOGIN);
        PendingIntent piLogin = PendingIntent.getService(this, 1, login,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, WifiMonitorService.class).setAction(ACTION_STOP);
        PendingIntent piStop = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = new Notification.Builder(this, CH_ID)
                .setContentTitle("校园网自动登录")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentIntent(piOpen)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_menu_send, "立即登录", piLogin)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "停止", piStop);
        return b.build();
    }

    private void notifyStatus(String text) {
        try {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(1, buildNotification(text));
        } catch (Throwable ignored) { }
    }
}
