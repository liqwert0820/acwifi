package com.school.autowifi;

import android.content.Context;
import android.content.SharedPreferences;

public class Config {
    private static final String PREF = "auto_wifi_pref";

    public static final String K_SSID = "ssid";
    public static final String K_WIFI_PASS = "wifi_pass";
    public static final String K_URL = "url";
    public static final String K_USER = "user";
    public static final String K_PASS = "pass";
    public static final String K_USER_KEY = "user_key";
    public static final String K_PASS_KEY = "pass_key";
    public static final String K_METHOD = "method";       // POST / GET
    public static final String K_EXTRA = "extra";         // 隐藏字段 name=value&...
    public static final String K_SUCCESS = "success_keyword";
    public static final String K_MONITOR = "monitoring";
    public static final String K_MODE = "mode";           // auto / web / http
    public static final String K_INTERVAL = "interval";   // 秒
    public static final String K_DELAY = "delay";         // 认证提交后等待几秒再校验
    public static final String K_RETRY = "retry";         // 校验失败重试次数
    public static final String K_BG_MODE = "bg_mode";    // default / night / sunset / photo
    public static final String K_LAST_FAMILY = "last_family";
    public static final String K_LAST_RESULT = "last_result";
    public static final String K_OK_COUNT = "ok_count";

    private final SharedPreferences sp;

    public Config(Context ctx) {
        sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public String get(String key, String def) {
        String v = sp.getString(key, def == null ? "" : def);
        if (v == null) v = "";
        if (K_PASS.equals(key) || K_WIFI_PASS.equals(key)) return Crypto.decrypt(v);
        return v;
    }

    public void set(String key, String val) {
        if (val == null) val = "";
        if (K_PASS.equals(key) || K_WIFI_PASS.equals(key)) {
            sp.edit().putString(key, val.isEmpty() ? "" : Crypto.encrypt(val)).apply();
            return;
        }
        sp.edit().putString(key, val).apply();
    }

    public int getInt(String key, int def) {
        try {
            return Integer.parseInt(get(key, String.valueOf(def)));
        } catch (Exception e) {
            return def;
        }
    }

    public void setInt(String key, int val) {
        set(key, String.valueOf(val));
    }

    public boolean isMonitoring() {
        return sp.getBoolean(K_MONITOR, false);
    }

    public void setMonitoring(boolean on) {
        sp.edit().putBoolean(K_MONITOR, on).apply();
    }

    public boolean isReady() {
        return !get(K_SSID, "").isEmpty()
                && !get(K_URL, "").isEmpty()
                && !get(K_USER, "").isEmpty()
                && !get(K_PASS, "").isEmpty();
    }
}
