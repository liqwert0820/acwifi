package com.school.autowifi;

import android.app.Application;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class App extends Application {

    public static final String CRASH_FILE = "crash.txt";

    @Override
    public void onCreate() {
        super.onCreate();
        LogStore.init(this);
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw);
                sw.append("时间：").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
                        .format(new Date())).append('\n');
                sw.append("机型：").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                        .append(" / Android ").append(Build.VERSION.RELEASE).append('\n');
                throwable.printStackTrace(pw);
                pw.flush();
                try (PrintWriter out = new PrintWriter(
                        openFileOutput(CRASH_FILE, MODE_PRIVATE))) {
                    out.print(sw.toString());
                }
                String log = sw.toString().replace("\n", " | ");
                LogStore.add("CRASH", log.length() > 800 ? log.substring(0, 800) : log);
            } catch (Throwable ignored) { }

            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    Toast.makeText(getApplicationContext(),
                            "程序异常：点开APP可查看崩溃日志", Toast.LENGTH_LONG).show();
                } catch (Throwable ignored) { }
            });

            if (previous != null) previous.uncaughtException(thread, throwable);
        });
    }
}
