package com.school.autowifi;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Typeface;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int[] INTERVALS = {3, 5, 10, 30};
    private static final int[] DELAYS = {3, 5, 6, 8, 10, 15};
    private static final int[] RETRIES = {0, 1, 2, 3};
    private static final String[] MODES = {"auto", "web", "http"};

    private EditText etSsid, etWifiPass, etUrl, etUser, etPass, etUserKey, etPassKey, etSuccess;
    private Spinner spInterval, spMode, spDelay, spRetry;
    private TextView tvStatus, tvLog, tvOutput;
    private Button btnToggle, btnAutoDetect, btnTest, btnSave, btnLoginNow, btnCapture, btnVerify,
            btnEyePass, btnEyeWifi, btnSuggestion, btnBattery, btnExport, btnImport, btnClearLog,
            btnDiagnose, btnExportLog, btnShareLog;

    private ImageView bgImage;
    private View bgDim;
    private View panelLogin, panelAdv, panelLog, advForm;
    private Button tabLogin, tabAdv, tabLog, btnAdvancedToggle, btnBg, btnFamilies, btnAbout;

    private static final int REQ_PICK_BG = 200;
    private static final String BG_FILE = "bg_image.jpg";

    private Config cfg;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private static final int REQ_PERM = 100;

    private final Runnable statusLoop = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            refreshOutput();
            ui.postDelayed(this, 2000);
        }
    };

    private void refreshOutput() {
        if (tvOutput != null) tvOutput.setText(LogStore.tail(30));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            initUi();
        } catch (Throwable t) {
            String chain = recordFatal("初始化", t);
            emergencyFallback(t, chain);
        }
    }

    /** 启动阶段控件绑定与事件挂载 */
    private void initUi() {
        setContentView(R.layout.activity_main);

        etSsid = findViewById(R.id.etSsid);
        etWifiPass = findViewById(R.id.etWifiPass);
        etUrl = findViewById(R.id.etUrl);
        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);
        etUserKey = findViewById(R.id.etUserKey);
        etPassKey = findViewById(R.id.etPassKey);
        etSuccess = findViewById(R.id.etSuccessKeyword);
        spInterval = findViewById(R.id.spInterval);
        spMode = findViewById(R.id.spMode);
        spDelay = findViewById(R.id.spDelay);
        spRetry = findViewById(R.id.spRetry);
        tvStatus = findViewById(R.id.tvStatus);
        tvLog = findViewById(R.id.tvLog);
        tvOutput = findViewById(R.id.tvOutput);
        btnToggle = findViewById(R.id.btnToggle);
        btnAutoDetect = findViewById(R.id.btnAutoDetect);
        btnTest = findViewById(R.id.btnTest);
        btnSave = findViewById(R.id.btnSave);
        btnLoginNow = findViewById(R.id.btnLoginNow);
        btnCapture = findViewById(R.id.btnCapture);
        btnVerify = findViewById(R.id.btnVerify);
        btnEyePass = findViewById(R.id.btnEyePass);
        btnEyeWifi = findViewById(R.id.btnEyeWifi);
        btnSuggestion = findViewById(R.id.btnSuggestion);
        btnBattery = findViewById(R.id.btnBattery);
        btnExport = findViewById(R.id.btnExport);
        btnImport = findViewById(R.id.btnImport);
        btnClearLog = findViewById(R.id.btnClearLog);
        btnDiagnose = findViewById(R.id.btnDiagnose);
        btnExportLog = findViewById(R.id.btnExportLog);
        btnShareLog = findViewById(R.id.btnShareLog);

        bgImage = findViewById(R.id.bgImage);
        bgDim = findViewById(R.id.bgDim);
        panelLogin = findViewById(R.id.panelLogin);
        panelAdv = findViewById(R.id.panelAdv);
        panelLog = findViewById(R.id.panelLog);
        advForm = findViewById(R.id.advForm);
        tabLogin = findViewById(R.id.tabLogin);
        tabAdv = findViewById(R.id.tabAdv);
        tabLog = findViewById(R.id.tabLog);
        btnAdvancedToggle = findViewById(R.id.btnAdvancedToggle);
        btnBg = findViewById(R.id.btnBg);
        btnFamilies = findViewById(R.id.btnFamilies);
        btnAbout = findViewById(R.id.btnAbout);

        cfg = new Config(this);
        loadToForm();
        requestPermissions();
        showCrashIfAny();

        btnSave.setOnClickListener(v -> {
            if (save()) toast("已保存");
        });
        btnAutoDetect.setOnClickListener(v -> doAutoDetect());
        btnCapture.setOnClickListener(v -> startActivity(new Intent(this, CaptureActivity.class)));
        btnTest.setOnClickListener(v -> loginAndVerify("测试"));
        btnLoginNow.setOnClickListener(v -> loginAndVerify("手动"));
        btnVerify.setOnClickListener(v -> verifyOnly());
        btnEyePass.setOnClickListener(v -> toggleVisibility(etPass, btnEyePass));
        btnEyeWifi.setOnClickListener(v -> toggleVisibility(etWifiPass, btnEyeWifi));
        btnToggle.setOnClickListener(v -> toggleMonitor());
        btnSuggestion.setOnClickListener(v -> addSuggestion());
        btnBattery.setOnClickListener(v -> openBatterySettings());
        btnExport.setOnClickListener(v -> exportConfig());
        btnImport.setOnClickListener(v -> importConfig());
        btnDiagnose.setOnClickListener(v -> runDiagnose());
        btnExportLog.setOnClickListener(v -> exportLog());
        btnShareLog.setOnClickListener(v -> shareLog());
        btnClearLog.setOnClickListener(v -> {
            History.clear(this);
            LogStore.clear(this);
            tvLog.setText("");
            refreshOutput();
            toast("已清空记录与日志");
        });

        tabLogin.setOnClickListener(v -> selectTab(0));
        tabAdv.setOnClickListener(v -> selectTab(1));
        tabLog.setOnClickListener(v -> selectTab(2));
        btnAdvancedToggle.setOnClickListener(v -> toggleAdvForm());
        btnBg.setOnClickListener(v -> showBgDialog());
        btnFamilies.setOnClickListener(v -> showFamilies());
        btnAbout.setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));

        selectTab(0);
        applyBackground();
        refreshToggleButton();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadToForm();
        ui.post(statusLoop);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(statusLoop);
        super.onPause();
    }

    // ================= 状态 =================

    private void refreshStatus() {
        String ssid = NetHelper.currentSsid(this);
        boolean online = NetHelper.isNetworkValidated(this);
        String last = cfg.get(Config.K_LAST_RESULT, "");
        if (last.isEmpty()) last = "暂无";

        StringBuilder sb = new StringBuilder();
        sb.append("当前 WiFi：").append(ssid.isEmpty() ? "未连接" : ssid).append('\n');
        sb.append("门户类型：").append(cfg.get(Config.K_LAST_FAMILY, "未探测")).append('\n');
        sb.append("外网状态：").append(online ? "已联网" : "未联网 / 待认证").append('\n');
        sb.append("后台监控：").append(cfg.isMonitoring() ? "运行中（每 "
                + cfg.getInt(Config.K_INTERVAL, 5) + " 秒检测）" : "已停止").append('\n');
        sb.append("成功次数：").append(cfg.getInt(Config.K_OK_COUNT, 0)).append('\n');
        sb.append("上次结果：").append(last);
        tvStatus.setText(sb.toString());
        tvStatus.setTextColor(Color.parseColor(online ? "#2E9E5B" : "#1B2A3A"));
        refreshToggleButton();
    }

    /** 把启动阶段未捕获异常落盘，并返回逐层 cause 链（便于在安全页直接展示真因） */
    private String recordFatal(String stage, Throwable t) {
        StringBuilder chain = new StringBuilder();
        Throwable c = t;
        int depth = 0;
        while (c != null && depth < 8) {
            chain.append(c.getClass().getName()).append(": ")
                    .append(c.getMessage() == null ? "" : c.getMessage()).append('\n');
            c = c.getCause();
            depth++;
        }
        try {
            LogStore.add("CRASH", stage + " " + t);
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            try (java.io.PrintWriter out = new java.io.PrintWriter(
                    openFileOutput(App.CRASH_FILE, MODE_PRIVATE))) {
                out.print(stage + " 阶段异常\n" + chain + "\n----- 栈 -----\n" + sw);
            }
        } catch (Throwable ignored) { }
        return chain.toString();
    }

    /** 取最内层异常的简短信息，用于 Toast 提示 */
    private String deepestMessage(Throwable t) {
        Throwable c = t, last = t;
        while (c != null) { last = c; c = c.getCause(); }
        return last.getClass().getSimpleName()
                + (last.getMessage() == null ? "" : ": " + last.getMessage());
    }

    /** 主界面加载失败时的纯代码安全页：不依赖 XML 布局，保证不闪退并展示完整异常链 */
    private void emergencyFallback(Throwable t, String chain) {
        try {
            Toast.makeText(this, "启动异常（已进入安全模式）：" + deepestMessage(t),
                    Toast.LENGTH_LONG).show();

            ScrollView scroll = new ScrollView(this);
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            int pad = (int) (24 * getResources().getDisplayMetrics().density);
            box.setPadding(pad, pad, pad, pad);

            TextView title = new TextView(this);
            title.setText("启动安全模式");
            title.setTextSize(20);
            title.setTypeface(Typeface.DEFAULT_BOLD);

            TextView body = new TextView(this);
            body.setTextIsSelectable(true);
            body.setTextSize(13);
            body.setPadding(0, pad / 2, 0, 0);
            body.setText("主界面加载失败，下面是完整异常链，请截图反馈：\n\n" + chain);

            box.addView(title);
            box.addView(body);
            scroll.addView(box);
            setContentView(scroll);
        } catch (Throwable ignored) { }
    }

    private void showCrashIfAny() {        File f = new File(getFilesDir(), App.CRASH_FILE);
        if (f.exists()) {
            StringBuilder sb = new StringBuilder("上次崩溃日志（截图反馈用）：\n");
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String line;
                int n = 0;
                while ((line = br.readLine()) != null && n < 10) {
                    sb.append(line).append('\n');
                    n++;
                }
            } catch (Exception ignored) { }
            tvLog.setText(sb.toString());
        }
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] perms;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                perms = new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.POST_NOTIFICATIONS};
            } else {
                perms = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
            }
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(perms, REQ_PERM);
            }
        }
    }

    // ================= 配置读写 =================

    private void loadToForm() {
        etSsid.setText(cfg.get(Config.K_SSID, ""));
        etWifiPass.setText(cfg.get(Config.K_WIFI_PASS, ""));
        etUrl.setText(cfg.get(Config.K_URL, ""));
        etUser.setText(cfg.get(Config.K_USER, ""));
        etPass.setText(cfg.get(Config.K_PASS, ""));
        etUserKey.setText(cfg.get(Config.K_USER_KEY, ""));
        etPassKey.setText(cfg.get(Config.K_PASS_KEY, ""));
        etSuccess.setText(cfg.get(Config.K_SUCCESS, ""));
        int sec = cfg.getInt(Config.K_INTERVAL, 5);
        for (int i = 0; i < INTERVALS.length; i++) {
            if (INTERVALS[i] == sec) {
                spInterval.setSelection(i);
                break;
            }
        }
        int delay = cfg.getInt(Config.K_DELAY, 6);
        for (int i = 0; i < DELAYS.length; i++) {
            if (DELAYS[i] == delay) {
                spDelay.setSelection(i);
                break;
            }
        }
        int retry = cfg.getInt(Config.K_RETRY, 2);
        for (int i = 0; i < RETRIES.length; i++) {
            if (RETRIES[i] == retry) {
                spRetry.setSelection(i);
                break;
            }
        }
        String mode = cfg.get(Config.K_MODE, "auto");
        for (int i = 0; i < MODES.length; i++) {
            if (MODES[i].equals(mode)) {
                spMode.setSelection(i);
                break;
            }
        }
    }

    private boolean save() {
        String ssid = etSsid.getText().toString().trim();
        String url = etUrl.getText().toString().trim();
        String user = etUser.getText().toString().trim();
        String pass = etPass.getText().toString();

        if (ssid.isEmpty() || url.isEmpty() || user.isEmpty() || pass.isEmpty()) {
            toast("请填写 WiFi名称、登录地址、账号、密码（后三项可先点自动识别）");
            return false;
        }

        cfg.set(Config.K_SSID, ssid);
        cfg.set(Config.K_WIFI_PASS, etWifiPass.getText().toString());
        cfg.set(Config.K_URL, url);
        cfg.set(Config.K_USER, user);
        cfg.set(Config.K_PASS, pass);
        cfg.set(Config.K_USER_KEY, etUserKey.getText().toString().trim());
        cfg.set(Config.K_PASS_KEY, etPassKey.getText().toString().trim());
        cfg.set(Config.K_SUCCESS, etSuccess.getText().toString().trim());
        int idx = spInterval.getSelectedItemPosition();
        cfg.setInt(Config.K_INTERVAL, INTERVALS[idx < 0 || idx >= INTERVALS.length ? 1 : idx]);
        int didx = spDelay.getSelectedItemPosition();
        cfg.setInt(Config.K_DELAY, DELAYS[didx < 0 || didx >= DELAYS.length ? 2 : didx]);
        int ridx = spRetry.getSelectedItemPosition();
        cfg.setInt(Config.K_RETRY, RETRIES[ridx < 0 || ridx >= RETRIES.length ? 2 : ridx]);
        int midx = spMode.getSelectedItemPosition();
        cfg.set(Config.K_MODE, MODES[midx < 0 || midx >= MODES.length ? 0 : midx]);
        return true;
    }

    // ================= 动作 =================

    private void doAutoDetect() {
        btnAutoDetect.setEnabled(false);
        tvLog.setText("正在探测认证页面…");
        final String ssid = NetHelper.currentSsid(this);
        if (!ssid.isEmpty() && etSsid.getText().toString().trim().isEmpty()) {
            etSsid.setText(ssid);
        }
        new Thread(() -> {
            String msg;
            try {
                msg = NetHelper.autoDetectAndApply(cfg);
            } catch (Throwable t) {
                msg = "识别异常：" + t.getClass().getSimpleName() + " " + t.getMessage();
            }
            final String result = msg;
            ui.post(() -> {
                btnAutoDetect.setEnabled(true);
                loadToForm();
                tvLog.setText(result);
                if (cfg.get(Config.K_SSID, "").isEmpty() && !ssid.isEmpty()) {
                    cfg.set(Config.K_SSID, ssid);
                    etSsid.setText(ssid);
                }
                refreshStatus();
            });
        }, "detect-worker").start();
    }

    /** 登录 → 自动校验能否真正访问外网；按配置的登录方式分派 */
    private void loginAndVerify(String tag) {
        if (!save()) return;
        String mode = cfg.get(Config.K_MODE, "auto");
        if ("http".equals(mode)) {
            httpLogin(tag, false);
        } else {
            webLogin(tag, "auto".equals(mode));
        }
    }

    private void webLogin(String tag, boolean fallbackHttp) {
        tvLog.setText("正在后台打开认证页并自动填写（" + tag + "）…");
        WebLoginEngine.login(this, cfg, (ok, detail) -> ui.post(() -> {
            if (ok) {
                cfg.setInt(Config.K_OK_COUNT, cfg.getInt(Config.K_OK_COUNT, 0) + 1);
                History.add(this, true, tag + "网页登录：" + detail);
                tvLog.setText("✅ 网页登录已提交：" + detail + "\n等待门户放行后再校验…");
                delayedVerify(tag, "网页登录：" + detail);
            } else if (fallbackHttp) {
                tvLog.setText("网页登录未成功：" + detail + "\n改用接口提交再试一次…");
                httpLogin(tag, true);
            } else {
                History.add(this, false, tag + "网页登录：" + detail);
                tvLog.setText("❌ 网页登录失败：" + detail
                        + "\n\n" + History.text(this));
                refreshStatus();
            }
        }));
    }

    private void httpLogin(String tag, boolean afterWebFail) {
        tvLog.setText("正在提交登录接口（" + tag + "）…");
        NetHelper.doLogin(this, cfg, (ok, msg) -> ui.post(() -> {
            if (ok) cfg.setInt(Config.K_OK_COUNT, cfg.getInt(Config.K_OK_COUNT, 0) + 1);
            History.add(this, ok, tag + "：" + msg);
            tvLog.setText((afterWebFail ? "（网页登录失败后的接口尝试）\n" : "")
                    + (ok ? "✅ " : "❌ ") + msg + "\n等待门户放行后再校验…");
            if (ok) {
                delayedVerify(tag, msg);
            } else {
                NetHelper.verifyAccess(this, (online, vmsg) -> ui.post(() -> {
                    finishVerify(online, vmsg, msg);
                }));
            }
        }));
    }

    /** 认证提交后先等待 delay 秒再校验；校验失败按配置重试，每次重试前同样等待 */
    private void delayedVerify(String tag, String loginMsg) {
        final int delay = Math.max(3, cfg.getInt(Config.K_DELAY, 6));
        final int retry = Math.max(0, cfg.getInt(Config.K_RETRY, 2));
        LogStore.add("WAIT", "认证提交完成，等待 " + delay + " 秒再校验网络…");
        tvLog.setText("认证已提交，等待 " + delay + " 秒再校验网络…");
        ui.postDelayed(() -> verifyWithRetry(tag, loginMsg, 0, delay, retry), delay * 1000L);
    }

    private void verifyWithRetry(String tag, String loginMsg, int attempt, int delay, int retry) {
        NetHelper.verifyAccess(this, (online, vmsg) -> ui.post(() -> {
            if (online || attempt >= retry) {
                finishVerify(online, vmsg, loginMsg);
                return;
            }
            int next = attempt + 1;
            LogStore.add("WAIT", "第 " + next + "/" + retry + " 次校验未通过，" + delay + " 秒后重试…");
            tvLog.setText("第 " + next + " 次校验未通过，等待 " + delay
                    + " 秒后重试（" + next + "/" + retry + "）…");
            ui.postDelayed(() -> verifyWithRetry(tag, loginMsg, next, delay, retry),
                    delay * 1000L);
        }));
    }

    private void finishVerify(boolean online, String vmsg, String loginMsg) {
        String all = (loginMsg == null || loginMsg.isEmpty() ? "" :
                (online ? "✅ 登录：" : "❌ 登录：") + loginMsg + "\n")
                + (online ? "✅ 可以访问网页：" : "❌ 仍无法上网：") + vmsg;
        cfg.set(Config.K_LAST_RESULT, (online ? "✅ " : "❌ ") + vmsg);
        History.add(this, online, "校验：" + vmsg);
        tvLog.setText(all + "\n\n" + History.text(this));
        refreshStatus();
    }

    /** 只校验网络，不登录 */
    private void verifyOnly() {
        tvLog.setText("正在校验能否访问网页…");
        NetHelper.verifyAccess(this, (online, msg) -> ui.post(() -> {
            cfg.set(Config.K_LAST_RESULT, (online ? "✅ " : "❌ ") + msg);
            History.add(this, online, "校验：" + msg);
            tvLog.setText((online ? "✅ 可以访问网页：" : "❌ 无法访问：") + msg
                    + "\n\n" + History.text(this));
            refreshStatus();
        }));
    }

    private void toggleMonitor() {
        if (cfg.isMonitoring()) {
            cfg.setMonitoring(false);
            stopService(new Intent(this, WifiMonitorService.class));
            toast("已停止监控");
        } else {
            if (!save()) return;
            cfg.setMonitoring(true);
            try {
                Intent svc = new Intent(this, WifiMonitorService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(svc);
                } else {
                    startService(svc);
                }
                toast("监控已启动");
            } catch (Throwable t) {
                cfg.setMonitoring(false);
                toast("启动失败：" + t.getClass().getSimpleName() + " " + t.getMessage());
            }
        }
        refreshToggleButton();
        refreshStatus();
    }

    private void addSuggestion() {
        String ssid = etSsid.getText().toString().trim();
        if (ssid.isEmpty()) {
            toast("请先填写 WiFi 名称");
            return;
        }
        String pass = etWifiPass.getText().toString();
        String result = WifiSuggestion.add(this, ssid, pass);
        tvLog.setText(result);
    }

    private void openBatterySettings() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    toast("已经在白名单里了");
                    tvLog.setText("✅ 已在电池优化白名单中，后台不会被限制。");
                    return;
                }
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
                tvLog.setText("已打开电池优化申请页，点【允许】即可。");
                return;
            }
            openAppDetail();
        } catch (Throwable t) {
            openAppDetail();
        }
    }

    private void openAppDetail() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
            tvLog.setText("请在设置里把本应用设为「不受限制」的后台运行。");
        } catch (Throwable t) {
            tvLog.setText("无法打开设置页：" + t.getClass().getSimpleName());
        }
    }

    // ================= 配置导入导出 =================

    private void exportConfig() {
        if (!save()) return;
        try {
            JSONObject o = new JSONObject();
            o.put("ssid", cfg.get(Config.K_SSID, ""));
            o.put("wifi_pass", cfg.get(Config.K_WIFI_PASS, ""));
            o.put("url", cfg.get(Config.K_URL, ""));
            o.put("user", cfg.get(Config.K_USER, ""));
            o.put("pass", cfg.get(Config.K_PASS, ""));
            o.put("user_key", cfg.get(Config.K_USER_KEY, ""));
            o.put("pass_key", cfg.get(Config.K_PASS_KEY, ""));
            o.put("method", cfg.get(Config.K_METHOD, "POST"));
            o.put("extra", cfg.get(Config.K_EXTRA, ""));
            o.put("success", cfg.get(Config.K_SUCCESS, ""));
            o.put("interval", cfg.getInt(Config.K_INTERVAL, 5));
            o.put("delay", cfg.getInt(Config.K_DELAY, 6));
            o.put("retry", cfg.getInt(Config.K_RETRY, 2));
            o.put("bg_mode", cfg.get(Config.K_BG_MODE, "default"));
            copy(o.toString(), "配置已复制到剪贴板（含密码，别外传）");
        } catch (Throwable t) {
            toast("导出失败：" + t.getClass().getSimpleName());
        }
    }

    private void importConfig() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null
                    || cm.getPrimaryClip().getItemCount() == 0) {
                toast("剪贴板是空的");
                return;
            }
            String text = cm.getPrimaryClip().getItemAt(0).coerceToText(this).toString().trim();
            if (!text.startsWith("{")) {
                toast("剪贴板里没有可识别的配置内容");
                return;
            }
            JSONObject o = new JSONObject(text);
            cfg.set(Config.K_SSID, o.optString("ssid", ""));
            cfg.set(Config.K_WIFI_PASS, o.optString("wifi_pass", ""));
            cfg.set(Config.K_URL, o.optString("url", ""));
            cfg.set(Config.K_USER, o.optString("user", ""));
            cfg.set(Config.K_PASS, o.optString("pass", ""));
            cfg.set(Config.K_USER_KEY, o.optString("user_key", ""));
            cfg.set(Config.K_PASS_KEY, o.optString("pass_key", ""));
            cfg.set(Config.K_METHOD, o.optString("method", "POST"));
            cfg.set(Config.K_EXTRA, o.optString("extra", ""));
            cfg.set(Config.K_SUCCESS, o.optString("success", ""));
            cfg.setInt(Config.K_INTERVAL, o.optInt("interval", 5));
            cfg.setInt(Config.K_DELAY, o.optInt("delay", 6));
            cfg.setInt(Config.K_RETRY, o.optInt("retry", 2));
            cfg.set(Config.K_BG_MODE, o.optString("bg_mode", "default"));
            loadToForm();
            toast("配置已导入");
        } catch (Throwable t) {
            toast("导入失败：内容格式不对");
        }
    }

    private void copy(String text, String msg) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("autowifi_config", text));
            toast(msg);
        } catch (Throwable t) {
            toast("复制失败");
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ================= 诊断与日志 =================

    private void runDiagnose() {
        tvLog.setText("正在诊断，大约 10 秒…");
        LogStore.add("UI", "用户点了诊断");
        new Thread(() -> {
            String report;
            try {
                report = NetHelper.diagnose(getApplicationContext(), cfg);
            } catch (Throwable t) {
                report = "诊断过程异常：" + t.getClass().getSimpleName() + " " + t.getMessage();
            }
            final String r = report;
            ui.post(() -> {
                tvLog.setText(r);
                copySilently(r);
                toast("诊断完成，已复制到剪贴板，直接发我即可");
            });
        }, "diag-worker").start();
    }

    private String buildLogText() {
        StringBuilder sb = new StringBuilder();
        sb.append(LogStore.dump(this));
        sb.append("\n----- 登录记录 -----\n").append(History.text(this));
        File f = new File(getFilesDir(), App.CRASH_FILE);
        if (f.exists()) {
            sb.append("\n----- 上次崩溃 -----\n");
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String line;
                int n = 0;
                while ((line = br.readLine()) != null && n < 30) {
                    sb.append(line).append('\n');
                    n++;
                }
            } catch (Exception ignored) { }
        }
        sb.append("\n----- 当前配置（密码已脱敏）-----\n");
        sb.append("SSID：").append(cfg.get(Config.K_SSID, "")).append('\n');
        sb.append("门户类型：").append(cfg.get(Config.K_LAST_FAMILY, "未探测")).append('\n');
        sb.append("登录地址：").append(cfg.get(Config.K_URL, "")).append('\n');
        sb.append("方式：").append(cfg.get(Config.K_METHOD, "POST")).append('\n');
        sb.append("字段：").append(cfg.get(Config.K_USER_KEY, "")).append(" / ")
                .append(cfg.get(Config.K_PASS_KEY, "")).append('\n');
        sb.append("附带参数：").append(cfg.get(Config.K_EXTRA, "")).append('\n');
        sb.append("账号：").append(cfg.get(Config.K_USER, "")).append('\n');
        sb.append("密码长度：").append(cfg.get(Config.K_PASS, "").length()).append('\n');
        sb.append("校验延迟：").append(cfg.getInt(Config.K_DELAY, 6)).append(" 秒\n");
        sb.append("失败重试：").append(cfg.getInt(Config.K_RETRY, 2)).append(" 次\n");
        return sb.toString();
    }

    private void exportLog() {
        String text = buildLogText();
        copy(text, "日志已复制到剪贴板");
        Uri uri = saveLogToDownloads(text);
        tvLog.setText(text.length() > 2000 ? text.substring(text.length() - 2000) : text);
        if (uri == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            toast("日志已复制到剪贴板（保存文件失败）");
        }
    }

    private void shareLog() {
        String text = buildLogText();
        Uri uri = saveLogToDownloads(text);
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "校园网自动登录 诊断日志");
            i.putExtra(Intent.EXTRA_TEXT, text.length() > 20000 ? text.substring(0, 20000) : text);
            if (uri != null) {
                i.putExtra(Intent.EXTRA_STREAM, uri);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            startActivity(Intent.createChooser(i, "分享日志"));
        } catch (Throwable t) {
            copy(text, "分享失败，已复制到剪贴板");
        }
    }

    /** Android 10+ 用 MediaStore 存到「下载/AutoWifi」，无需存储权限 */
    private Uri saveLogToDownloads(String text) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            File f = LogStore.saveToDownloads(this, text);
            if (f != null) toast("已保存到 " + f.getAbsolutePath());
            return null;
        }
        try {
            String name = "autowifi-log-"
                    + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.CHINA).format(new Date()) + ".txt";
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/AutoWifi");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return null;
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os != null) os.write(text.getBytes());
            }
            toast("已保存到 下载/AutoWifi/" + name);
            return uri;
        } catch (Throwable t) {
            return null;
        }
    }

    private void copySilently(String text) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("autowifi_log", text));
        } catch (Throwable ignored) { }
    }

    private void toggleVisibility(EditText et, Button btn) {
        boolean nowVisible = "隐藏".contentEquals(btn.getText());
        if (nowVisible) {
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            btn.setText("显示");
        } else {
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            btn.setText("隐藏");
        }
        try {
            et.setSelection(et.getText().length());
        } catch (Throwable ignored) { }
    }

    private void refreshToggleButton() {
        btnToggle.setText(cfg.isMonitoring() ? "停止后台监控" : "③ 启动后台监控");
    }

    // ================= 标签页与折叠 =================

    private void selectTab(int idx) {
        panelLogin.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        panelAdv.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        panelLog.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);
        Button[] tabs = {tabLogin, tabAdv, tabLog};
        for (int i = 0; i < tabs.length; i++) {
            boolean sel = i == idx;
            tabs[i].setBackgroundResource(sel ? R.drawable.bg_primary : R.drawable.bg_secondary);
            tabs[i].setTextColor(Color.parseColor(sel ? "#FFFFFF" : "#5B6B7B"));
        }
    }

    private void toggleAdvForm() {
        boolean open = advForm.getVisibility() != View.VISIBLE;
        advForm.setVisibility(open ? View.VISIBLE : View.GONE);
        btnAdvancedToggle.setText(open ? "▾ 高级表单（字段名 / 关键词）"
                : "▸ 高级表单（字段名 / 关键词）");
    }

    // ================= 背景设置 =================

    private void showFamilies() {
        String[] items = new String[PortalFamily.SUPPORTED.length + 1];
        for (int i = 0; i < PortalFamily.SUPPORTED.length; i++) {
            items[i] = PortalFamily.SUPPORTED[i][0] + "\n    " + PortalFamily.SUPPORTED[i][1];
        }
        items[items.length - 1] = "适配边界\n    专用客户端协议、802.1X、短信/图形验证码不自动适配";
        new AlertDialog.Builder(this)
                .setTitle("支持的门户产品族（按族适配，非逐校内置）")
                .setItems(items, null)
                .setPositiveButton("知道了", null)
                .show();
    }

    private void showBgDialog() {        String[] items = {"默认蓝青渐变", "夜幕深紫渐变", "朝霞橙粉渐变",
                "从相册选择一张图片", "恢复浅色纯色背景"};
        new AlertDialog.Builder(this)
                .setTitle("设置背景")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0: setBgMode("default"); break;
                        case 1: setBgMode("night"); break;
                        case 2: setBgMode("sunset"); break;
                        case 3: pickBgPhoto(); break;
                        default: setBgMode("none"); break;
                    }
                })
                .show();
    }

    private void setBgMode(String mode) {
        cfg.set(Config.K_BG_MODE, mode);
        applyBackground();
    }

    private void pickBgPhoto() {
        try {
            Intent i = new Intent(Intent.ACTION_PICK);
            i.setType("image/*");
            startActivityForResult(i, REQ_PICK_BG);
        } catch (Throwable t) {
            toast("无法打开相册：" + t.getClass().getSimpleName());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_BG || resultCode != RESULT_OK
                || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        new Thread(() -> {
            try {
                Bitmap bmp = decodeUri(uri);
                if (bmp == null) {
                    ui.post(() -> toast("图片读取失败"));
                    return;
                }
                File f = new File(getFilesDir(), BG_FILE);
                try (FileOutputStream fos = new FileOutputStream(f)) {
                    bmp.compress(Bitmap.CompressFormat.JPEG, 82, fos);
                }
                cfg.set(Config.K_BG_MODE, "photo");
                ui.post(() -> {
                    applyBackground();
                    toast("背景已设置");
                });
            } catch (Throwable t) {
                ui.post(() -> toast("保存背景失败：" + t.getClass().getSimpleName()));
            }
        }, "bg-decode").start();
    }

    private Bitmap decodeUri(Uri uri) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream is = getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(is, null, o);
        if (is != null) is.close();
        int max = 1080;
        int sample = 1;
        while (o.outWidth / sample > max || o.outHeight / sample > max) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        InputStream is2 = getContentResolver().openInputStream(uri);
        Bitmap b = BitmapFactory.decodeStream(is2, null, o2);
        if (is2 != null) is2.close();
        return b;
    }

    private void applyBackground() {
        try {
            String mode = cfg.get(Config.K_BG_MODE, "default");
            if ("photo".equals(mode)) {
                File f = new File(getFilesDir(), BG_FILE);
                if (f.exists()) {
                    Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
                    if (b != null) {
                        bgImage.setImageBitmap(b);
                        bgDim.setAlpha(0.35f);
                        return;
                    }
                }
                mode = "default";
            }
            switch (mode) {
                case "night":
                    bgImage.setImageResource(R.drawable.bg_grad_night);
                    bgDim.setAlpha(0.3f);
                    break;
                case "sunset":
                    bgImage.setImageResource(R.drawable.bg_grad_sunset);
                    bgDim.setAlpha(0.35f);
                    break;
                case "none":
                    bgImage.setImageDrawable(null);
                    bgDim.setAlpha(1f);
                    break;
                default:
                    bgImage.setImageResource(R.drawable.bg_header);
                    bgDim.setAlpha(0.45f);
                    break;
            }
        } catch (Throwable t) {
            LogStore.add("CRASH", "背景设置异常 " + t);
        }
    }
}
