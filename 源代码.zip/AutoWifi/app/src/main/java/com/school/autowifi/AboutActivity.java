package com.school.autowifi;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/** 关于页：版本、简介、Telegram 频道入口与链接复制 */
public class AboutActivity extends Activity {

    public static final String CHANNEL_URL = "https://t.me/aotcwifi";

    private TextView tvVersion, tvTgLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_about);

            tvVersion = findViewById(R.id.tvVersion);
            tvTgLink = findViewById(R.id.tvTgLink);
            Button btnBack = findViewById(R.id.btnBack);
            Button btnOpenTg = findViewById(R.id.btnOpenTg);
            Button btnCopyTg = findViewById(R.id.btnCopyTg);

            String ver = "版本 " + versionName() + "（" + versionCode() + "）";
            tvVersion.setText(ver);
            tvTgLink.setText(CHANNEL_URL);

            btnBack.setOnClickListener(v -> finish());
            btnOpenTg.setOnClickListener(v -> openChannel());
            btnCopyTg.setOnClickListener(v -> copyChannel());
        } catch (Throwable t) {
            LogStore.add("CRASH", "关于页异常 " + t);
            Toast.makeText(this, "页面异常：" + t.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void openChannel() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(CHANNEL_URL));
            startActivity(i);
        } catch (Throwable t) {
            copyChannel();
            Toast.makeText(this, "无法打开 Telegram，已复制链接：" + t.getClass().getSimpleName(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void copyChannel() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("telegram_channel", CHANNEL_URL));
                Toast.makeText(this, "链接已复制", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable t) {
            Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show();
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "?";
        }
    }

    private int versionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Throwable t) {
            return 0;
        }
    }
}
