package com.school.autowifi;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSuggestion;
import android.os.Build;

import java.util.Collections;

/**
 * 用系统官方的「网络建议」API 实现自动连接校园网。
 * 首次添加后系统会弹通知让用户允许，允许之后进入该 WiFi 范围由系统自动连接，APP 无需再介入。
 */
public class WifiSuggestion {

    private static final int SUCCESS = 0;              // STATUS_NETWORK_SUGGESTIONS_SUCCESS
    private static final int ERROR_DUPLICATE = 3;      // STATUS_NETWORK_SUGGESTIONS_ERROR_ADD_DUPLICATE

    public static String add(Context ctx, String ssid, String pass) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return "当前系统低于 Android 10，不支持自动连接建议，只能手动连接 WiFi。";
        }
        if (ssid == null || ssid.isEmpty()) return "请先填写 WiFi 名称。";
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return "本机不支持网络建议 API。";

            WifiNetworkSuggestion.Builder b = new WifiNetworkSuggestion.Builder().setSsid(ssid);
            if (pass != null && !pass.isEmpty()) {
                b.setWpa2Passphrase(pass);
            }
            WifiNetworkSuggestion s = b.build();
            int r = wm.addNetworkSuggestions(Collections.singletonList(s));
            if (r == SUCCESS) {
                return "✅ 已提交自动连接建议。\n系统可能弹一条通知，点【允许】之后，手机进入该 WiFi 范围会自动连上，无需再手动点。";
            }
            if (r == ERROR_DUPLICATE) {
                return "这条 WiFi 已经在建议列表里了，不用重复添加。";
            }
            return "添加失败，系统返回码：" + r + "（2=应用不被允许，3=重复，4=超出数量上限）。";
        } catch (Throwable t) {
            return "添加失败：" + t.getClass().getSimpleName() + " " + t.getMessage()
                    + "\n（若是 802.1X 企业认证校园网，需在系统 WiFi 设置里手动填账号密码）";
        }
    }

    public static String remove(Context ctx, String ssid) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "系统版本不支持。";
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return "本机不支持网络建议 API。";
            WifiNetworkSuggestion.Builder b = new WifiNetworkSuggestion.Builder().setSsid(ssid);
            int r = wm.removeNetworkSuggestions(Collections.singletonList(b.build()));
            return r == SUCCESS ? "✅ 已移除该 WiFi 的自动连接建议。" : "移除失败，返回码：" + r;
        } catch (Throwable t) {
            return "移除失败：" + t.getClass().getSimpleName();
        }
    }
}
