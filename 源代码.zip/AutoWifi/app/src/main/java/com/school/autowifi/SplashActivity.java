package com.school.autowifi;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 启动自检页：纯代码绘制（不解析任何 XML 布局），逐步执行初始化体检。
 * 任何一步失败都停在当前页展示完整异常链，不会无声闪退，也不会进入半残的主界面。
 */
public class SplashActivity extends Activity {

    private static final String[] STEP_NAMES = {
            "初始化日志与崩溃记录",
            "读取本机保存的配置",
            "自检主界面布局（关键项）",
            "自检凭证加密模块",
            "检查运行权限",
    };

    private static final int COLOR_STEP_IDLE = 0xFF9FB3C8;
    private static final int COLOR_STEP_RUN = 0xFFFFD166;
    private static final int COLOR_STEP_OK = 0xFF5CE1A6;
    private static final int COLOR_STEP_BAD = 0xFFFF6B6B;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final TextView[] stepViews = new TextView[STEP_NAMES.length];

    private TextView tvSub, tvError, tvVersion;
    private LinearLayout errBox;
    private Button btnRetry, btnSafe, btnCopy;

    private int cur = 0;
    private long stepStart = 0;
    private String lastChain = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            buildUi();
            ui.postDelayed(this::next, 260);
        } catch (Throwable t) {
            // 连启动页都建不起来时，直接交给主界面自己的安全模式兜底
            goMain();
        }
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ================= 界面（全部代码构建） =================

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF081522, 0xFF0E2E4A, 0xFF12405F});

        ScrollView scroll = new ScrollView(this);
        scroll.setBackground(bg);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(52), dp(24), dp(28));

        TextView logo = new TextView(this);
        logo.setText("");
        logo.setTextSize(46);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(0x22FFFFFF, 26, 0x33FFFFFF));
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(88), dp(88));
        root.addView(logo, logoLp);

        TextView title = new TextView(this);
        title.setText("校园网自动登录");
        title.setTextSize(21);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(16), 0, 0);
        root.addView(title);

        tvSub = new TextView(this);
        tvSub.setText("启动自检 · 逐步加载");
        tvSub.setTextSize(12);
        tvSub.setTextColor(0xFF9FB3C8);
        tvSub.setGravity(Gravity.CENTER);
        tvSub.setPadding(0, dp(6), 0, 0);
        root.addView(tvSub);

        // 步骤卡片
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(round(0x261A3350, 18, 0x33FFFFFF));
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.topMargin = dp(28);
        root.addView(card, cardLp);

        for (int i = 0; i < STEP_NAMES.length; i++) {
            TextView row = new TextView(this);
            row.setTextSize(13);
            row.setTextColor(COLOR_STEP_IDLE);
            row.setLineSpacing(dp(3), 1f);
            row.setPadding(0, dp(7), 0, dp(7));
            row.setText("○  " + STEP_NAMES[i]);
            stepViews[i] = row;
            card.addView(row);
        }

        // 失败面板
        errBox = new LinearLayout(this);
        errBox.setOrientation(LinearLayout.VERTICAL);
        errBox.setBackground(round(0x2EFF6B6B, 18, 0x55FF6B6B));
        errBox.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams errLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        errLp.topMargin = dp(16);
        root.addView(errBox, errLp);
        errBox.setVisibility(View.GONE);

        TextView errTitle = new TextView(this);
        errTitle.setText("启动中断");
        errTitle.setTextSize(14);
        errTitle.setTextColor(0xFFFF9E9E);
        errTitle.setTypeface(Typeface.DEFAULT_BOLD);
        errBox.addView(errTitle);

        tvError = new TextView(this);
        tvError.setTextSize(11);
        tvError.setTextColor(0xFFE6EDF5);
        tvError.setTextIsSelectable(true);
        tvError.setPadding(0, dp(8), 0, 0);
        errBox.addView(tvError);

        btnRetry = makeBtn("重新自检", 0xFFFFFFFF, 0xFF1E88E5);
        btnSafe = makeBtn("以安全模式继续进入", 0x22FFFFFF, 0x66FFFFFF);
        btnCopy = makeBtn("复制错误详情", 0x22FFFFFF, 0x66FFFFFF);
        errBox.addView(btnRetry);
        errBox.addView(btnSafe);
        errBox.addView(btnCopy);

        btnRetry.setOnClickListener(v -> retryAll());
        btnSafe.setOnClickListener(v -> goMain());
        btnCopy.setOnClickListener(v -> copyError());

        tvVersion = new TextView(this);
        tvVersion.setTextSize(11);
        tvVersion.setTextColor(0x66FFFFFF);
        tvVersion.setGravity(Gravity.CENTER);
        tvVersion.setPadding(0, dp(22), 0, 0);
        tvVersion.setText("版本 " + versionName() + "　·　MIT License");
        root.addView(tvVersion);

        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    private GradientDrawable round(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private Button makeBtn(String text, int fill, int textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(textColor);
        b.setBackground(round(fill, 13, 0));
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        b.setStateListAnimator(null);
        return b;
    }

    // ================= 分步执行 =================

    private void next() {
        if (cur >= STEP_NAMES.length) {
            finishSteps();
            return;
        }
        int i = cur;
        stepViews[i].setText("◐  " + STEP_NAMES[i]);
        stepViews[i].setTextColor(COLOR_STEP_RUN);
        stepStart = SystemClock.elapsedRealtime();
        ui.postDelayed(() -> runOne(i), 100);
    }

    private void runOne(int i) {
        try {
            String detail = doStep(i);
            long ms = SystemClock.elapsedRealtime() - stepStart;
            setStepDone(i, detail, ms);
            cur = i + 1;
            ui.postDelayed(this::next, 170);
        } catch (Throwable t) {
            long ms = SystemClock.elapsedRealtime() - stepStart;
            lastChain = chainOf(t);
            try {
                LogStore.add("BOOT", "第 " + (i + 1) + " 步失败：" + t);
            } catch (Throwable ignored) { }
            String where = "第 " + (i + 1) + " 步「" + STEP_NAMES[i] + "」失败";
            stepViews[i].setText("✗  " + STEP_NAMES[i] + "  ·  " + ms + "ms");
            stepViews[i].setTextColor(COLOR_STEP_BAD);
            showError(where, lastChain);
        }
    }

    private void setStepDone(int i, String detail, long ms) {
        StringBuilder sb = new StringBuilder("✓  ").append(STEP_NAMES[i]);
        if (detail != null && !detail.isEmpty()) sb.append("\n     ").append(detail);
        sb.append("  ·  ").append(ms).append("ms");
        stepViews[i].setText(sb.toString());
        stepViews[i].setTextColor(COLOR_STEP_OK);
    }

    private void finishSteps() {
        tvSub.setText("自检通过，正在进入主界面…");
        ui.postDelayed(this::goMain, 380);
    }

    /** 每一步的真具体检内容 */
    private String doStep(int i) throws Throwable {
        switch (i) {
            case 0: {
                LogStore.add("BOOT", "启动页进入");
                java.io.File dir = getFilesDir();
                if (dir == null) throw new IllegalStateException("filesDir 不可用");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("无法创建私有目录");
                return "私有目录可用";
            }
            case 1: {
                Config c = new Config(this);
                String ssid = c.get(Config.K_SSID, "");
                String url = c.get(Config.K_URL, "");
                if (ssid.isEmpty()) return "尚未配置，进入后填写";
                return "已保存：" + ssid + (url.isEmpty() ? "" : " / 接口已配置");
            }
            case 2: {
                // 关键体检：真正解析一次主界面布局，出问题在这里被抓住，而不是进主界面才闪退
                View v = getLayoutInflater().inflate(R.layout.activity_main, null);
                final int[] n = {0};
                countViews(v, n);
                if (n[0] < 10) throw new IllegalStateException("主界面控件数量异常：" + n[0]);
                return "布局解析正常，共 " + n[0] + " 个控件";
            }
            case 3: {
                String probe = "probe-" + SystemClock.elapsedRealtime();
                String enc = Crypto.encrypt(probe);
                String dec = Crypto.decrypt(enc);
                if (!probe.equals(dec)) throw new IllegalStateException("加解密往返结果不一致");
                if (enc.startsWith("enc:raw:")) return "已就绪（本机 Keystore 不可用，使用备用编码）";
                return "AndroidKeyStore AES-GCM 就绪";
            }
            case 4: {
                boolean loc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED;
                boolean noti = true;
                if (android.os.Build.VERSION.SDK_INT >= 33) {
                    noti = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            == PackageManager.PERMISSION_GRANTED;
                }
                if (loc && noti) return "定位与通知权限已授予";
                if (!loc) return "定位权限未授予（进入后可授权，否则读不到 WiFi 名称）";
                return "通知权限未授予（不影响登录，仅通知栏操作受限）";
            }
            default:
                return "";
        }
    }

    private void countViews(View v, int[] n) {
        n[0]++;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) countViews(g.getChildAt(i), n);
        }
    }

    // ================= 失败处理 =================

    private String chainOf(Throwable t) {
        StringBuilder sb = new StringBuilder();
        Throwable c = t;
        int d = 0;
        while (c != null && d < 8) {
            sb.append(d == 0 ? "" : "Caused by: ")
                    .append(c.getClass().getName())
                    .append(c.getMessage() == null ? "" : ": " + c.getMessage())
                    .append('\n');
            c = c.getCause();
            d++;
        }
        return sb.toString().trim();
    }

    private void showError(String where, String chain) {
        tvSub.setText("启动自检未通过");
        tvError.setText(where + "\n\n" + chain + "\n\n（可点「复制错误详情」后反馈）");
        errBox.setVisibility(View.VISIBLE);
        // 把失败信息也落一份，便于之后从日志看到
        try {
            java.io.PrintWriter out = new java.io.PrintWriter(
                    openFileOutput(App.CRASH_FILE, MODE_PRIVATE));
            out.print(where + "\n" + chain);
            out.close();
        } catch (Throwable ignored) { }
    }

    private void copyError() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("autowifi_boot_error", tvError.getText()));
                Toast.makeText(this, "错误详情已复制", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable t) {
            Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show();
        }
    }

    private void retryAll() {
        errBox.setVisibility(View.GONE);
        tvSub.setText("启动自检 · 逐步加载");
        for (int i = 0; i < stepViews.length; i++) {
            stepViews[i].setText("○  " + STEP_NAMES[i]);
            stepViews[i].setTextColor(COLOR_STEP_IDLE);
        }
        cur = 0;
        ui.postDelayed(this::next, 120);
    }

    private void goMain() {
        try {
            startActivity(new Intent(this, MainActivity.class));
        } catch (Throwable t) {
            try {
                Toast.makeText(this, "无法进入主界面：" + t.getClass().getSimpleName(),
                        Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) { }
        } finally {
            finish();
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "?";
        }
    }
}
