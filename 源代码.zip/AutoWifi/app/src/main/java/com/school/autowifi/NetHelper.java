package com.school.autowifi;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class NetHelper {

    public interface Callback {
        void onResult(boolean ok, String message);
    }

    public interface VerifyCallback {
        void onResult(boolean online, String message);
    }

    /** 真实校验能否访问外网：先看系统判定，再实际发请求确认，避免"提交成功但其实还是被拦" */
    public static void verifyAccess(final Context ctx, final VerifyCallback cb) {
        new Thread(() -> {
            boolean online = false;
            String msg = "";
            String[] targets = new String[]{
                    "http://connectivitycheck.gstatic.com/generate_204",
                    "https://www.baidu.com/",
                    "http://www.baidu.com/"
            };
            for (String t : targets) {
                HttpURLConnection c = null;
                try {
                    c = open(t, "GET");
                    int code = c.getResponseCode();
                    String loc = c.getHeaderField("Location");
                    String body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
                    c.disconnect();
                    c = null;

                    LogStore.add("VERIFY", t + " -> HTTP " + code
                            + (loc == null ? "" : " Location=" + loc)
                            + (body.contains("认证") ? " （认证页内容）" : ""));
                    if (code == 204) {
                        online = true;
                        msg = "HTTP 204，外网可直接访问";
                        break;
                    }                    if (code >= 300 && code < 400) {
                        msg = "被重定向到认证页：" + (loc == null ? "未知地址" : loc);
                        continue;
                    }
                    if (code == 200) {
                        String lower = body.toLowerCase();
                        boolean looksPortal = body.contains("认证")
                                || body.contains("登录") || lower.contains("portal")
                                || lower.contains("login");
                        if (t.startsWith("https") || (lower.contains("baidu") && !looksPortal)) {
                            online = true;
                            msg = "HTTP 200，页面正常返回";
                            break;
                        }
                        msg = "HTTP 200，但返回的是认证页内容";
                        continue;
                    }
                    msg = "HTTP " + code + "，响应异常";
                } catch (Throwable e) {
                    msg = "无法访问：" + e.getClass().getSimpleName();
                } finally {
                    if (c != null) c.disconnect();
                }
            }

            if (!online && isNetworkValidated(ctx)) {
                msg = (msg.isEmpty() ? "" : msg + "；") + "但系统已判定该网络可联网";
            }
            LogStore.add("VERIFY", "结果 online=" + online + " " + msg);
            cb.onResult(online, msg);
        }, "verify-worker").start();
    }

    // ================= 一键诊断 =================

    public static String diagnose(Context ctx, Config cfg) {
        StringBuilder sb = new StringBuilder();
        sb.append("===== 诊断报告 =====\n");
        sb.append("当前 WiFi：").append(currentSsid(ctx).isEmpty() ? "未连接" : currentSsid(ctx)).append('\n');
        sb.append("WiFi 已通外网：").append(isWifiValidated(ctx)).append('\n');
        sb.append("移动数据在使用：").append(isMobileActive(ctx)).append("（开着流量时容易误判为已联网）\n");

        sb.append("\n① 外网探测\n");
        String[] probes = new String[]{
                "http://connectivitycheck.gstatic.com/generate_204",
                "https://www.baidu.com/",
                "http://www.baidu.com/",
                "http://1.1.1.1/"
        };
        int lastCode = -1;
        String lastLoc = "";
        String lastBody = "";
        for (String t : probes) {
            HttpURLConnection c = null;
            try {
                c = open(t, "GET");
                int code = c.getResponseCode();
                String loc = c.getHeaderField("Location");
                String body = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
                sb.append("  ").append(t).append(" -> HTTP ").append(code);
                if (loc != null && !loc.isEmpty()) sb.append("，跳转 ").append(loc);
                if (body.toLowerCase().contains("<form")) sb.append("（返回认证页 HTML）");
                sb.append('\n');
                lastCode = code;
                lastLoc = loc == null ? "" : loc;
                lastBody = body;
                c.disconnect();
                c = null;
            } catch (Throwable e) {
                sb.append("  ").append(t).append(" -> 异常 ")
                        .append(e.getClass().getSimpleName()).append(' ')
                        .append(e.getMessage()).append('\n');
            } finally {
                if (c != null) c.disconnect();
            }
        }

        sb.append("\n② 认证页解析\n");
        PageResult pr = findPortalPage();
        if (pr == null) {
            sb.append("  未抓到认证页（可能已经联网，或被其他机制拦截）\n");
        } else {
            String family = PortalFamily.detect(pr.pageUrl, pr.html);
            cfg.set(Config.K_LAST_FAMILY, family);
            sb.append("  门户类型：").append(family)
                    .append("（建议：").append("web".equals(PortalFamily.preferredMode(family))
                            ? "网页静默登录" : "接口表单提交").append("）\n");
            sb.append("  认证页：").append(pr.pageUrl).append('\n');
            sb.append("  HTML 长度：").append(pr.html.length()).append('\n');
            String head = pr.html.length() > 300 ? pr.html.substring(0, 300) : pr.html;
            sb.append("  HTML 前 300 字：").append(head.replace("\n", " ")).append('\n');
        }

        sb.append("\n③ 当前登录配置\n");
        sb.append("  地址：").append(cfg.get(Config.K_URL, "")).append('\n');
        sb.append("  方式：").append(cfg.get(Config.K_METHOD, "POST")).append('\n');
        sb.append("  字段：").append(cfg.get(Config.K_USER_KEY, "username"))
                .append(" / ").append(cfg.get(Config.K_PASS_KEY, "password")).append('\n');
        sb.append("  附带参数长度：").append(cfg.get(Config.K_EXTRA, "").length()).append('\n');
        sb.append("  账号：").append(cfg.get(Config.K_USER, "")).append('\n');
        sb.append("  密码：已填写（长度 ").append(cfg.get(Config.K_PASS, "").length()).append("）\n");

        sb.append("\n④ 登录请求实测\n");
        int loginCode = -1;
        String loginLoc = "";
        String loginBody = "";
        String loginUrl = cfg.get(Config.K_URL, "").trim();
        if (loginUrl.isEmpty()) {
            sb.append("  未配置登录地址，已跳过\n");
        } else {
            HttpURLConnection c = null;
            try {
                String userKey = cfg.get(Config.K_USER_KEY, "username");
                String passKey = cfg.get(Config.K_PASS_KEY, "password");
                String method = cfg.get(Config.K_METHOD, "POST").toUpperCase();
                String extra = cfg.get(Config.K_EXTRA, "");
                StringBuilder bodyB = new StringBuilder();
                if (!extra.isEmpty()) bodyB.append(extra).append('&');
                bodyB.append(enc(userKey)).append('=').append(enc(cfg.get(Config.K_USER, "")))
                        .append('&').append(enc(passKey)).append('=').append(enc(cfg.get(Config.K_PASS, "")));
                String payload = bodyB.toString();
                String target = "GET".equals(method)
                        ? loginUrl + (loginUrl.contains("?") ? "&" : "?") + payload
                        : loginUrl;

                c = open(target, "GET".equals(method) ? "GET" : "POST");
                if (!"GET".equals(method)) {
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    try (OutputStream os = c.getOutputStream()) {
                        os.write(payload.getBytes(StandardCharsets.UTF_8));
                    }
                }
                loginCode = c.getResponseCode();
                loginLoc = c.getHeaderField("Location") == null ? "" : c.getHeaderField("Location");
                loginBody = readAll(loginCode >= 400 ? c.getErrorStream() : c.getInputStream());
                sb.append("  ").append(method).append(' ').append(loginUrl).append('\n');
                sb.append("  参数：").append(extra.isEmpty() ? "" : extra + "&")
                        .append(userKey).append('=').append(cfg.get(Config.K_USER, ""))
                        .append('&').append(passKey).append("=***\n");
                sb.append("  响应 HTTP ").append(loginCode)
                        .append(loginLoc.isEmpty() ? "" : "，跳转 ").append(loginLoc).append('\n');
                String lb = loginBody.length() > 400 ? loginBody.substring(0, 400) : loginBody;
                sb.append("  响应体：").append(lb.replace("\n", " ")).append('\n');
                c.disconnect();
                c = null;
            } catch (Throwable e) {
                sb.append("  登录请求异常：").append(e.getClass().getSimpleName())
                        .append(' ').append(e.getMessage()).append('\n');
            } finally {
                if (c != null) c.disconnect();
            }
            LogStore.add("DIAG", "登录实测 HTTP " + loginCode + " " + loginLoc);
        }

        sb.append("\n⑤ 登录后再探测\n");
        HttpURLConnection c2 = null;
        int code2 = -1;
        try {
            c2 = open("http://connectivitycheck.gstatic.com/generate_204", "GET");
            code2 = c2.getResponseCode();
            sb.append("  generate_204 -> HTTP ").append(code2).append('\n');
            c2.disconnect();
            c2 = null;
        } catch (Throwable e) {
            sb.append("  再探测异常：").append(e.getClass().getSimpleName()).append('\n');
        } finally {
            if (c2 != null) c2.disconnect();
        }

        sb.append("\n⑥ 结论与建议\n");
        String lower = loginBody.toLowerCase();
        if (code2 == 204) {
            sb.append("  ✅ 目前外网可通，无需登录；若仍上不了网，检查是否个别网站被限制。\n");
        } else if (loginUrl.isEmpty()) {
            sb.append("  ⚠ 登录地址为空：请先点「自动识别」或「内置浏览器抓包」。\n");
        } else if (lower.contains("密码") && (lower.contains("错误") || lower.contains("不正确"))
                || lower.contains("invalid") || lower.contains("wrong password")) {
            sb.append("  ⚠ 服务端提示密码错误：账号或密码不对，或需要专用客户端加密。\n");
        } else if (loginCode >= 200 && loginCode < 400 && code2 != 204) {
            sb.append("  ⚠ 登录返回成功但外网仍不通：可能是缺 token/隐藏参数、\n"
                    + "    需要二次确认（回跳认证页）、设备数超限、账号欠费或被限速。\n");
        } else if (loginCode == 404 || loginCode == 405) {
            sb.append("  ⚠ 登录地址不正确（").append(loginCode).append("）：接口路径或请求方式不对。\n");
        } else if (loginCode < 0) {
            sb.append("  ⚠ 登录请求没发出去：检查地址、证书或网络。\n");
        } else {
            sb.append("  ⚠ 登录返回 HTTP ").append(loginCode)
                    .append("，未生效：把本报告发我，按响应内容调接口。\n");
        }
        if (lastCode == 302 && lastLoc.contains("https") && lastBody.isEmpty()) {
            sb.append("  · 认证页走 HTTPS 跳转，若页面打不开是证书问题，内置浏览器已自动放行。\n");
        }
        String all = (loginBody + " " + lastBody + " " + loginUrl).toLowerCase();
        if (all.contains("giwifi") || all.contains("gportal")) {
            sb.append("  · 识别为 GiWiFi / GPortal 门户：登录参数里的 sign 是每次请求重算的签名（还有 iv），\n"
                    + "    照抄旧 sign 必然失效，请把登录方式切到「网页静默登录」。\n");
        }
        if (cfg.get(Config.K_EXTRA, "").contains("sign=")) {
            sb.append("  · 当前配置里存着旧的 sign 参数，接口方式基本不可能成功，建议改用网页登录。\n");
        }
        if (isMobileActive(ctx)) {
            sb.append("  · 检测到移动数据在用：判定联网请关掉流量测一次，避免被蜂窝网络误导。\n");
        }
        sb.append("\n（密码已脱敏；把整段发我即可定位）\n");
        LogStore.add("DIAG", "诊断完成");
        return sb.toString();
    }

    private static final String UA = "Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

    // ================= WiFi 状态 =================

    public static String currentSsid(Context ctx) {
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return "";
            WifiInfo info = wm.getConnectionInfo();
            if (info == null) return "";
            String ssid = info.getSSID();
            if (ssid == null) return "";
            if (ssid.startsWith("\"") && ssid.endsWith("\"") && ssid.length() > 1) {
                ssid = ssid.substring(1, ssid.length() - 1);
            }
            return ssid;
        } catch (Throwable t) {
            return "";
        }
    }

    public static boolean isNetworkValidated(Context ctx) {
        return isWifiValidated(ctx);
    }

    /** 只看 WiFi 网络的联网状态：避免开着移动数据时被误判为"已联网" */
    public static boolean isWifiValidated(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network active = cm.getActiveNetwork();
            if (active != null) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(active);
                if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    return nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                }
            }
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                    return true;
                }
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 当前是否正在走移动数据（排查误判用） */
    public static boolean isMobileActive(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network active = cm.getActiveNetwork();
            NetworkCapabilities nc = cm.getNetworkCapabilities(active);
            return nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
        } catch (Throwable t) {
            return false;
        }
    }

    // ================= 网络工具 =================

    private static SSLContext trustAllCtx() throws Exception {
        TrustManager[] tm = new TrustManager[]{new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] chain, String authType) { }
            public void checkServerTrusted(X509Certificate[] chain, String authType) { }
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        }};
        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, tm, new SecureRandom());
        return sc;
    }

    private static HttpURLConnection open(String url, String method) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        if (conn instanceof HttpsURLConnection) {
            HttpsURLConnection h = (HttpsURLConnection) conn;
            try {
                h.setSSLSocketFactory(trustAllCtx().getSocketFactory());
            } catch (Exception ignored) { }
            h.setHostnameVerifier((hostname, session) -> true);
        }
        conn.setRequestMethod(method);
        conn.setConnectTimeout(6000);
        conn.setReadTimeout(8000);
        conn.setInstanceFollowRedirects(false);
        conn.setRequestProperty("User-Agent", UA);
        conn.setRequestProperty("Accept", "text/html,application/json,*/*");
        return conn;
    }

    private static String readAll(InputStream is) {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        } catch (Exception ignored) { }
        return sb.toString();
    }

    // ================= 自动识别门户登录接口 =================

    public static class PageResult {
        public String pageUrl;
        public String html;
    }

    private static final String[] PROBES = new String[]{
            "http://connectivitycheck.gstatic.com/generate_204",
            "http://www.baidu.com/",
            "http://1.1.1.1/"
    };

    public static PageResult findPortalPage() {
        for (String probe : PROBES) {
            HttpURLConnection conn = null;
            try {
                conn = open(probe, "GET");
                int code = conn.getResponseCode();
                String loc = conn.getHeaderField("Location");
                if (loc == null || loc.isEmpty()) loc = conn.getHeaderField("location");
                String body = readAll(code >= 400 ? conn.getErrorStream() : conn.getInputStream());
                conn.disconnect();
                conn = null;
                LogStore.add("PROBE", probe + " -> HTTP " + code
                        + (loc == null ? "" : " Location=" + loc)
                        + (body.toLowerCase().contains("<form") ? " (含form)" : ""));

                if (loc != null && !loc.isEmpty()
                        && !loc.contains("gstatic.com") && !loc.contains("google")) {
                    PageResult pr = fetchPage(loc);
                    if (pr != null) return pr;
                }
                if (body != null && body.toLowerCase().contains("<form")) {
                    PageResult pr = new PageResult();
                    pr.pageUrl = probe;
                    pr.html = body;
                    return pr;
                }
            } catch (Exception e) {
                LogStore.add("PROBE", probe + " -> 异常 " + e.getClass().getSimpleName() + " " + e.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        LogStore.add("PROBE", "未找到认证页（可能已联网，或网络受限）");
        return null;
    }

    /** 探测当前认证页地址（门户地址常带 wlanuserip，重连后会变，登录前要重新取） */
    public static String freshPortalUrl() {
        HttpURLConnection c = null;
        try {
            c = open("http://connectivitycheck.gstatic.com/generate_204", "GET");
            int code = c.getResponseCode();
            String loc = c.getHeaderField("Location");
            c.disconnect();
            c = null;
            LogStore.add("PORTAL", "探测认证页 HTTP " + code + " loc=" + loc);
            if (loc != null && loc.toLowerCase().startsWith("http")) return loc;
        } catch (Throwable t) {
            LogStore.add("PORTAL", "探测认证页异常 " + t.getClass().getSimpleName());
        } finally {
            if (c != null) c.disconnect();
        }
        return "";
    }

    private static PageResult fetchPage(String url) {        HttpURLConnection conn = null;
        try {
            conn = open(url, "GET");
            int code = conn.getResponseCode();
            String body = readAll(code >= 400 ? conn.getErrorStream() : conn.getInputStream());
            String finalUrl = conn.getURL().toString();
            conn.disconnect();
            conn = null;
            PageResult pr = new PageResult();
            pr.pageUrl = finalUrl;
            pr.html = body;
            return pr;
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static final Pattern FORM_PAT = Pattern.compile("<form([^>]*)>([\\s\\S]*?)</form>", Pattern.CASE_INSENSITIVE);
    private static final Pattern INPUT_PAT = Pattern.compile("<input([^>]*)>", Pattern.CASE_INSENSITIVE);

    private static String attr(String tagAttrs, String name) {
        Pattern p = Pattern.compile("(?<![A-Za-z0-9_-])" + name
                + "\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(tagAttrs);
        if (m.find()) {
            if (m.group(2) != null) return m.group(2);
            if (m.group(3) != null) return m.group(3);
            if (m.group(4) != null) return m.group(4);
        }
        return "";
    }

    /** 自动解析页面里的登录表单并写回配置，返回给用户看的说明 */
    public static String autoDetectAndApply(Config cfg) {
        PageResult pr = findPortalPage();
        if (pr == null || pr.html == null || pr.html.isEmpty()) {
            return "没探测到认证页面。请确认已连上校园 WiFi、且尚未登录，再点一次。";
        }
        String family = PortalFamily.detect(pr.pageUrl, pr.html);
        cfg.set(Config.K_LAST_FAMILY, family);
        LogStore.add("PORTAL", "识别门户类型：" + family);
        Matcher fm = FORM_PAT.matcher(pr.html);
        String bestAction = null, bestMethod = null, bestUser = null, bestPass = null, bestExtra = "";
        String found = "";

        while (fm.find()) {
            String formAttrs = fm.group(1);
            String inner = fm.group(2);
            Matcher im = INPUT_PAT.matcher(inner);
            String userField = null, passField = null;
            Map<String, String> extras = new LinkedHashMap<>();
            boolean hasPass = false;

            while (im.find()) {
                String a = im.group(1);
                String name = attr(a, "name");
                if (name.isEmpty()) name = attr(a, "id");
                String type = attr(a, "type").toLowerCase();
                String value = attr(a, "value");
                if (name.isEmpty()) continue;

                if ("password".equals(type)) {
                    passField = name;
                    hasPass = true;
                } else if ("text".equals(type) || "tel".equals(type)
                        || "number".equals(type) || "email".equals(type)) {
                    if (userField == null) userField = name;
                } else if ("hidden".equals(type) && !value.isEmpty()) {
                    extras.put(name, value);
                }
            }
            if (!hasPass || userField == null) continue;

            String action = attr(formAttrs, "action");
            if (action.isEmpty()) action = pr.pageUrl;
            else if (!action.toLowerCase().startsWith("http")) {
                try {
                    action = new URL(new URL(pr.pageUrl), action).toString();
                } catch (Exception e) {
                    action = pr.pageUrl;
                }
            }
            String method = attr(formAttrs, "method");
            if (method.isEmpty()) method = "POST";

            bestAction = action;
            bestMethod = method.toUpperCase();
            bestUser = userField;
            bestPass = passField;
            StringBuilder ex = new StringBuilder();
            for (Map.Entry<String, String> e : extras.entrySet()) {
                if (ex.length() > 0) ex.append('&');
                ex.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
            }
            bestExtra = ex.toString();
            found = "表单字段：" + userField + " / " + passField;
            break;
        }

        if (bestAction == null) {
            return "找到认证页（" + pr.pageUrl + "），但没识别出标准表单。\n"
                    + "多半是 JS 动态登录（锐捷 srun / 深澜 / Dr.COM 常见），需要抓包后手动填。";
        }

        cfg.set(Config.K_URL, bestAction);
        cfg.set(Config.K_USER_KEY, bestUser);
        cfg.set(Config.K_PASS_KEY, bestPass);
        cfg.set(Config.K_METHOD, bestMethod);
        cfg.set(Config.K_EXTRA, bestExtra);

        return "✅ 已自动识别：\n门户类型：" + family
                + "\n认证页：" + pr.pageUrl
                + "\n提交地址：" + bestAction
                + "\n请求方式：" + bestMethod
                + "\n" + found
                + "\n隐藏字段：" + (bestExtra.isEmpty() ? "无" : "已捕获 " + bestExtra.length() + " 字符")
                + "\n建议方式：" + ("web".equals(PortalFamily.preferredMode(family)) ? "网页静默登录"
                        : "接口表单提交")
                + "\n\n填好学号和密码，点【测试登录】。";
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    // ================= 登录 =================

    /** 根据返回内容判断成功与否：true 成功 / false 失败 / null 无法判断 */
    private static Boolean judgeBody(String body) {
        if (body == null) return null;
        String t = body.trim();
        if (t.startsWith("{") || t.startsWith("[")) {
            try {
                JSONObject o = new JSONObject(t);
                if (o.has("code")) {
                    int c = o.optInt("code", -1);
                    return c == 0 || c == 200;
                }
                if (o.has("errcode")) {
                    return o.optInt("errcode", -1) == 0;
                }
                if (o.has("errno")) {
                    return o.optInt("errno", -1) == 0;
                }
                if (o.has("success")) {
                    return o.optBoolean("success", false);
                }
                if (o.has("result")) {
                    String r = o.optString("result", "");
                    return r.equalsIgnoreCase("ok") || r.equals("1") || r.equalsIgnoreCase("true");
                }
                if (o.has("msg") || o.has("message")) {
                    String m = o.optString("msg", "") + o.optString("message", "");
                    if (m.contains("成功") || m.toLowerCase().contains("success")) return true;
                    if (m.contains("失败") || m.contains("错误") || m.toLowerCase().contains("fail")) return false;
                }
            } catch (Throwable ignored) { }
        }
        String lower = t.toLowerCase();
        if (lower.contains("密码错误") || lower.contains("认证失败") || lower.contains("登录失败")
                || lower.contains("login failed") || lower.contains("invalid password")) {
            return false;
        }
        if (t.contains("登录成功") || lower.contains("success")) {
            return true;
        }
        return null;
    }

    public static void doLogin(final Context ctx, final Config cfg, final Callback cb) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String url = cfg.get(Config.K_URL, "").trim();
                if (url.isEmpty()) {
                    cb.onResult(false, "登录地址为空");
                    return;
                }
                String userKey = cfg.get(Config.K_USER_KEY, "").trim();
                String passKey = cfg.get(Config.K_PASS_KEY, "").trim();
                if (userKey.isEmpty()) userKey = "username";
                if (passKey.isEmpty()) passKey = "password";
                String method = cfg.get(Config.K_METHOD, "POST").trim().toUpperCase();
                String extra = cfg.get(Config.K_EXTRA, "").trim();

                StringBuilder body = new StringBuilder();
                if (!extra.isEmpty()) body.append(extra).append('&');
                body.append(enc(userKey)).append('=').append(enc(cfg.get(Config.K_USER, "")));
                body.append('&').append(enc(passKey)).append('=').append(enc(cfg.get(Config.K_PASS, "")));
                String payload = body.toString();

                String target = url;
                if ("GET".equals(method)) {
                    target = url + (url.contains("?") ? "&" : "?") + payload;
                }

                String masked = (extra.isEmpty() ? "" : extra + "&")
                        + userKey + "=" + cfg.get(Config.K_USER, "") + "&" + passKey + "=***（已隐藏）";
                LogStore.add("LOGIN", "发起 " + method + " " + url);
                LogStore.add("LOGIN", "参数 " + masked);

                conn = open(target, "GET".equals(method) ? "GET" : "POST");
                conn.setInstanceFollowRedirects(false);
                if (!"GET".equals(method)) {
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(payload.getBytes(StandardCharsets.UTF_8));
                    }
                }

                int code = conn.getResponseCode();
                String respBody = readAll(code >= 400 ? conn.getErrorStream() : conn.getInputStream());
                String loc = conn.getHeaderField("Location");
                String ct = conn.getHeaderField("Content-Type");
                conn.disconnect();
                conn = null;

                String logBody = respBody.length() > 300 ? respBody.substring(0, 300) : respBody;
                LogStore.add("LOGIN", "响应 HTTP " + code
                        + (loc == null ? "" : " Location=" + loc)
                        + (ct == null ? "" : " CT=" + ct));
                LogStore.add("LOGIN", "响应体 " + logBody.replace("\n", " "));

                boolean ok;
                String detail;
                String keyword = cfg.get(Config.K_SUCCESS, "").trim();
                if (!keyword.isEmpty()) {
                    ok = respBody.contains(keyword);
                    detail = ok ? "命中成功关键词" : "未命中关键词";
                } else {
                    Boolean j = judgeBody(respBody);
                    if (j != null) {
                        ok = j;
                        detail = ok ? "响应判定成功" : "响应判定失败";
                    } else {
                        ok = (code >= 200 && code < 400);
                        detail = "";
                    }
                }
                String snippet = respBody.length() > 160 ? respBody.substring(0, 160) : respBody;
                String msg = "HTTP " + code + (detail.isEmpty() ? "" : "，" + detail)
                        + (ok ? "，登录已提交" : "，可能未成功");
                cb.onResult(ok, msg + "\n返回片段：" + snippet.replace("\n", " ").trim());
            } catch (Exception e) {
                cb.onResult(false, "请求异常：" + e.getClass().getSimpleName() + " " + e.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        }, "login-worker").start();
    }
}
