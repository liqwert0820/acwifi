package com.school.autowifi;

/**
 * 校园网门户产品族识别。
 * 国内高校网关虽多，但基本落在几套公开产品族里；这里按 URL / 页面特征粗分，
 * 同一族的表单结构、加密提交套路相近，网页静默登录可复用同一套注入策略。
 * 注意：私有客户端协议（Dr.COM 2133 端口、锐捷/深澜专用客户端）和 802.1X 不在此列。
 */
public class PortalFamily {

    public static final String UNKNOWN = "未知门户";

    public static final String[][] SUPPORTED = {
            {"GiWiFi / GPortal（京东网关）", "网页静默登录；sign/iv 由页面 JS 生成"},
            {"锐捷 SRun（srun_portal）", "网页静默登录；挑战码/摘要由页面 JS 生成"},
            {"深澜 SDR / Dr.COM Web 门户", "网页静默登录或通用表单提交"},
            {"华为 ePortal / HGPortal", "网页静默登录；token 由页面携带"},
            {"H3C iMC / 自助页面", "通用表单提交，必要时转网页登录"},
            {"通用 Web 表单（带 <form>）", "自动识别 action 与账号/密码字段"},
            {"未知 / JS 动态门户", "后台 WebView 注入自动填表，失败可抓包回填"},
    };

    /** 依据认证页 URL 与 HTML 判断产品族；任一为空就只按另一项判断。 */
    public static String detect(String url, String html) {
        String u = url == null ? "" : url.toLowerCase();
        String h = html == null ? "" : html.toLowerCase();
        String t = u + " " + h;

        if (t.contains("gportal") || t.contains("giwifi")) return "GiWiFi / GPortal";
        if (t.contains("srun") || h.contains("srun_portal") || h.contains("srun_portal_pc")
                || h.contains("hdrs") && h.contains("challenge")) return "锐捷 SRun";
        if (t.contains("sdr") || t.contains("deeplearn") || h.contains("深澜")) return "深澜 SDR";
        if (t.contains("eportal") || t.contains("hgportal") || h.contains("wsnap")
                || h.contains("reglogin") || h.contains("huawei")) return "华为 ePortal";
        if (t.contains("drcom") || t.contains("dr.com") || t.contains("2133")
                || h.contains("城市热点")) return "Dr.COM / 城市热点";
        if (t.contains("h3c") || t.contains("imc") || h.contains("h3c")) return "H3C iMC";
        if (h.contains("<form")) return "通用 Web 表单";
        return UNKNOWN;
    }

    /** 该族建议优先使用的登录方式：web / http / auto */
    public static String preferredMode(String family) {
        if (family == null) return "auto";
        switch (family) {
            case "GiWiFi / GPortal":
            case "锐捷 SRun":
            case "深澜 SDR":
            case "华为 ePortal":
                return "web";
            case "H3C iMC":
            case "通用 Web 表单":
                return "http";
            default:
                return "auto";
        }
    }
}
