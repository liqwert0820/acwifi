package com.school.autowifi;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 登录历史：本地保存最近 15 条，带时间与结果 */
public class History {

    private static final String PREF = "auto_wifi_pref";
    private static final String KEY = "history";
    private static final int MAX = 15;

    public static void add(Context ctx, boolean ok, String msg) {
        try {
            JSONArray arr = raw(ctx);
            JSONObject o = new JSONObject();
            o.put("t", new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA).format(new Date()));
            o.put("ok", ok);
            o.put("m", (msg == null ? "" : msg).replace("\n", " "));
            JSONArray next = new JSONArray();
            next.put(o);
            for (int i = 0; i < arr.length() && next.length() < MAX; i++) {
                next.put(arr.get(i));
            }
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putString(KEY, next.toString()).apply();
        } catch (Throwable ignored) { }
    }

    public static String text(Context ctx) {
        try {
            JSONArray arr = raw(ctx);
            if (arr.length() == 0) return "";
            StringBuilder sb = new StringBuilder("最近记录：\n");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                sb.append(o.optString("t")).append("  ")
                        .append(o.optBoolean("ok") ? "✅ " : "❌ ")
                        .append(o.optString("m")).append('\n');
            }
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    public static void clear(Context ctx) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }

    private static JSONArray raw(Context ctx) {
        try {
            String s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]");
            return new JSONArray(s == null ? "[]" : s);
        } catch (Throwable t) {
            return new JSONArray();
        }
    }
}
