package com.school.autowifi;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;

/**
 * 内置浏览器抓包：在 APP 内打开校园网认证页。
 * 通过注入 JS 钩子记录 fetch / XMLHttpRequest / 原生表单提交，再读取页面表单结构，
 * 自动把「登录地址 + 请求方式 + 账号密码字段名 + 隐藏字段」写进配置。
 */
public class CaptureActivity extends Activity {

    private WebView web;
    private EditText etUrl;
    private ListView lv;
    private TextView tvInfo;

    private final ArrayList<String> rows = new ArrayList<>();
    private final ArrayList<JSONObject> reqs = new ArrayList<>();
    private final LinkedHashSet<String> seen = new LinkedHashSet<>();

    private ArrayAdapter<String> adapter;
    private Config cfg;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private String appliedUrl = "";
    private int bestScore = -1;
    private boolean finished = false;
    private boolean startValidated = false;

    private static final String JS_HOOK =
            "(function(){"
            + "if(window.__awHook)return;window.__awHook=1;window.__awLog=[];"
            + "function rec(m,u,b){try{window.__awLog.push({m:String(m||'GET').toUpperCase(),"
            + "u:String(u||''),b:String(b||'').slice(0,600)})}catch(e){}}"
            + "try{var of=window.fetch;if(of){window.fetch=function(input,init){try{"
            + "var u=(typeof input==='string')?input:(input&&input.url)||'';"
            + "var m=(init&&init.method)||'GET';var b=init&&init.body;"
            + "rec(m,u,(typeof b==='string')?b:(b?String(b):''))}catch(e){}return of.apply(this,arguments)}}}catch(e){}"
            + "try{var ox=XMLHttpRequest.prototype.open,os=XMLHttpRequest.prototype.send;"
            + "XMLHttpRequest.prototype.open=function(m,u){this.__awm=m;this.__awu=u;return ox.apply(this,arguments)};"
            + "XMLHttpRequest.prototype.send=function(b){try{rec(this.__awm||'POST',this.__awu,"
            + "(typeof b==='string')?b:'')}catch(e){}return os.apply(this,arguments)}}catch(e){}"
            + "try{document.addEventListener('submit',function(e){try{var f=e.target;"
            + "var a=new URL((f.getAttribute('action')||''),location.href).href;"
            + "var p=[];var els=f.querySelectorAll('input,select,textarea');"
            + "for(var i=0;i<els.length;i++){var n=els[i].name;if(!n)continue;"
            + "if(els[i].type==='submit'||els[i].type==='button'||els[i].type==='file')continue;"
            + "p.push(encodeURIComponent(n)+'='+encodeURIComponent(els[i].value||''))}"
            + "rec((f.getAttribute('method')||'POST').toUpperCase(),a,p.join('&'))}catch(x){}},true)}catch(e){}"
            + "})();";

    private static final String JS_FORMS =
            "(function(){var out=[];var fs=document.querySelectorAll('form');"
            + "for(var k=0;k<fs.length;k++){var f=fs[k];var els=f.querySelectorAll('input,select');"
            + "var items=[];for(var i=0;i<els.length;i++){var el=els[i];"
            + "items.push({n:el.name||el.id||'',t:(el.type||'').toLowerCase(),"
            + "v:(el.type==='password')?'':(el.value||'')});}"
            + "out.push({a:new URL((f.getAttribute('action')||''),location.href).href,"
            + "m:((f.getAttribute('method')||'POST')).toUpperCase(),i:items});}"
            + "return JSON.stringify(out);})()";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cfg = new Config(this);
        startValidated = NetHelper.isNetworkValidated(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        setContentView(root);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(8, 8, 8, 0);

        etUrl = new EditText(this);
        etUrl.setSingleLine(true);
        etUrl.setTextSize(12);
        etUrl.setHint("认证页地址，可留空由系统探测");
        etUrl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(etUrl);

        Button go = new Button(this);
        go.setText("打开");
        bar.addView(go);
        root.addView(bar);

        LinearLayout bar2 = new LinearLayout(this);
        bar2.setOrientation(LinearLayout.HORIZONTAL);
        bar2.setPadding(8, 0, 8, 0);

        Button forms = new Button(this);
        forms.setText("抓当前页表单");
        forms.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar2.addView(forms);

        Button clear = new Button(this);
        clear.setText("清空记录");
        clear.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar2.addView(clear);
        root.addView(bar2);

        tvInfo = new TextView(this);
        tvInfo.setTextSize(12);
        tvInfo.setPadding(10, 4, 10, 4);
        tvInfo.setText("在下面的页面里正常登录一次，抓到的请求会出现在列表里，点一条即可设为登录接口。");
        root.addView(tvInfo);

        web = new WebView(this);
        web.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 5));
        root.addView(web);

        lv = new ListView(this);
        lv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 3));
        root.addView(lv);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rows);
        lv.setAdapter(adapter);

        setupWeb();

        go.setOnClickListener(v -> {
            String u = etUrl.getText().toString().trim();
            if (TextUtils.isEmpty(u)) u = "http://1.1.1.1/";
            web.loadUrl(u);
        });

        forms.setOnClickListener(v -> harvestForms(true));

        clear.setOnClickListener(v -> {
            rows.clear();
            reqs.clear();
            seen.clear();
            adapter.notifyDataSetChanged();
        });

        lv.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            if (position < 0 || position >= reqs.size()) return;
            applyRequest(reqs.get(position));
        });

        // 自动探测认证页
        String start = etUrl.getText().toString().trim();
        web.loadUrl(TextUtils.isEmpty(start) ? "http://1.1.1.1/" : start);
        ui.post(harvestLoop);
    }

    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, android.net.http.SslError error) {
                // 校园网认证页普遍是自签名证书，这里放行便于抓包
                handler.proceed();
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (!TextUtils.isEmpty(url)) etUrl.setText(url);
                view.evaluateJavascript(JS_HOOK, null);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(JS_HOOK, null);
                harvestForms(false);
                harvestLog();
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                try {
                    String u = request.getUrl().toString();
                    String m = request.getMethod();
                    if (!u.endsWith(".css") && !u.endsWith(".js") && !u.endsWith(".png")
                            && !u.endsWith(".jpg") && !u.endsWith(".gif") && !u.endsWith(".ico")) {
                        addRequest(m, u, "");
                    }
                } catch (Throwable ignored) { }
                return null;
            }
        });
    }

    private final Runnable harvestLoop = new Runnable() {
        @Override
        public void run() {
            harvestLog();
            checkSuccess();
            ui.postDelayed(this, 1500);
        }
    };

    /** 检测到系统判定已联网 → 自动保存并返回 */
    private void checkSuccess() {
        if (finished || startValidated) return;
        try {
            if (NetHelper.isNetworkValidated(getApplicationContext())) {
                finished = true;
                tvInfo.setText("✅ 已成功联网，登录配置已自动保存，正在返回主界面…");
                ui.postDelayed(() -> {
                    setResult(RESULT_OK);
                    finish();
                }, 1200);
            }
        } catch (Throwable ignored) { }
    }

    /** 自动挑出最像登录接口的请求并写入配置 */
    private void autoConsider(String method, String url, String body) {
        if (finished || url == null || url.isEmpty()) return;
        int s = score(method, url, body);
        if (s < 6 || s <= bestScore) return;
        Map<String, String> params = paramsOf(body);
        if (params.isEmpty()) return;
        bestScore = s;
        applyParams(url, method, params, url, true);
    }

    private int score(String method, String url, String body) {
        int s = 0;
        String u = url.toLowerCase();
        String b = body == null ? "" : body.toLowerCase();
        if (b.contains("pass") || b.contains("pwd")) s += 5;
        if (u.contains("login") || u.contains("auth") || u.contains("portal")
                || u.contains("srun") || u.contains("eportal") || u.contains("wlan")
                || u.contains("radius")) s += 3;
        if (!"GET".equalsIgnoreCase(method)) s += 2;
        if (b.length() > 0) s += 1;
        return s;
    }

    private Map<String, String> paramsOf(String body) {
        Map<String, String> params = parseQuery(body);
        if (params.isEmpty() && body != null && body.trim().startsWith("{")) {
            try {
                JSONObject jo = new JSONObject(body);
                for (java.util.Iterator<String> it = jo.keys(); it.hasNext(); ) {
                    String k = it.next();
                    params.put(k, jo.optString(k, ""));
                }
            } catch (Throwable ignored) { }
        }
        return params;
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacks(harvestLoop);
        try {
            if (web != null) {
                web.stopLoading();
                web.destroy();
            }
        } catch (Throwable ignored) { }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(harvestLoop);
    }

    // ================= 收集 =================

    private void harvestLog() {
        if (web == null) return;
        web.evaluateJavascript("JSON.stringify(window.__awLog||[])", value -> {
            try {
                String raw = decodeJsString(value);
                JSONArray arr = new JSONArray(raw);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    addRequest(o.optString("m", "GET"), o.optString("u", ""), o.optString("b", ""));
                }
            } catch (Throwable ignored) { }
        });
    }

    private void addRequest(String method, String url, String body) {
        if (TextUtils.isEmpty(url)) return;
        String key = method + "|" + url + "|" + body;
        if (seen.contains(key)) return;
        seen.add(key);

        JSONObject o = new JSONObject();
        try {
            o.put("m", method);
            o.put("u", url);
            o.put("b", body);
        } catch (Throwable ignored) { }
        reqs.add(o);

        String line = method + "  " + compact(url);
        if (!TextUtils.isEmpty(body)) line += "\n   " + compact(body);
        rows.add(line);
        adapter.notifyDataSetChanged();
        lv.setSelection(rows.size() - 1);

        // 进页面后自动尝试识别登录请求，用户不用手动点
        autoConsider(method, url, body);
    }

    private static String compact(String s) {
        if (s == null) return "";
        String t = s.replace("\n", " ");
        return t.length() > 110 ? t.substring(0, 110) + "…" : t;
    }

    private static String decodeJsString(String v) {
        if (v == null) return "";
        try {
            Object o = new JSONTokener(v).nextValue();
            if (o instanceof String) return (String) o;
            return String.valueOf(o);
        } catch (Throwable t) {
            return v;
        }
    }

    // ================= 解析表单 =================

    private void harvestForms(boolean clickByUser) {
        if (web == null) return;
        web.evaluateJavascript(JS_FORMS, value -> {
            String raw = decodeJsString(value);
            boolean applied = false;
            String info = "";
            try {
                JSONArray forms = new JSONArray(raw);
                for (int i = 0; i < forms.length(); i++) {
                    JSONObject f = forms.getJSONObject(i);
                    JSONArray items = f.optJSONArray("i");
                    if (items == null) continue;

                    String userField = null, passField = null;
                    Map<String, String> extras = new LinkedHashMap<>();
                    for (int k = 0; k < items.length(); k++) {
                        JSONObject it = items.getJSONObject(k);
                        String n = it.optString("n", "");
                        String t = it.optString("t", "").toLowerCase();
                        String v = it.optString("v", "");
                        if (n.isEmpty()) continue;
                        if ("password".equals(t)) passField = n;
                        else if ("text".equals(t) || "tel".equals(t)
                                || "number".equals(t) || "email".equals(t)) {
                            if (userField == null) userField = n;
                        } else if ("hidden".equals(t) && !v.isEmpty()) {
                            extras.put(n, v);
                        }
                    }
                    if (userField == null || passField == null) continue;

                    cfg.set(Config.K_URL, f.optString("a", ""));
                    cfg.set(Config.K_METHOD, f.optString("m", "POST"));
                    cfg.set(Config.K_USER_KEY, userField);
                    cfg.set(Config.K_PASS_KEY, passField);
                    cfg.set(Config.K_EXTRA, buildQuery(extras));
                    applied = true;
                    info = "已从表单识别：\n地址 " + f.optString("a", "")
                            + "\n方式 " + f.optString("m", "POST")
                            + "\n字段 " + userField + " / " + passField
                            + "\n隐藏字段 " + extras.size() + " 个";
                    break;
                }
            } catch (Throwable ignored) { }

            if (applied) {
                tvInfo.setText("✅ " + info + "\n返回主界面填学号密码即可。");
                if (clickByUser) Toast.makeText(this, "已写入配置", Toast.LENGTH_SHORT).show();
            } else if (clickByUser) {
                tvInfo.setText("没找到带密码框的标准表单，试试在页面里登录一次，再从下面请求列表里点一条。");
            }
        });
    }

    private static String buildQuery(Map<String, String> map) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : map.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.toString();
    }

    // ================= 应用某条请求 =================

    private void applyRequest(JSONObject req) {
        final String url = req.optString("u", "");
        final String method = req.optString("m", "POST");
        final String body = req.optString("b", "");

        if (TextUtils.isEmpty(body)) {
            // 没有请求体（GET 或无 body），直接用整个 URL
            String path = url;
            Map<String, String> q = parseQuery(url.contains("?") ? url.substring(url.indexOf('?') + 1) : "");
            path = url.contains("?") ? url.substring(0, url.indexOf('?')) : url;
            applyParams(path, method, q, url, false);
            return;
        }
        Map<String, String> params = parseQuery(body);
        if (params.isEmpty()) {
            // JSON 体
            try {
                JSONObject jo = new JSONObject(body);
                for (java.util.Iterator<String> it = jo.keys(); it.hasNext(); ) {
                    String k = it.next();
                    String v = jo.optString(k, "");
                    params.put(k, v);
                }
            } catch (Throwable ignored) { }
        }
        applyParams(url, method, params, url, false);
    }

    private void applyParams(String url, String method, Map<String, String> params,
                             String shownUrl, boolean auto) {
        String userKey = null, passKey = null;

        for (Map.Entry<String, String> e : params.entrySet()) {
            String k = e.getKey().toLowerCase();
            if (passKey == null && (k.contains("pass") || k.contains("pwd"))) passKey = e.getKey();
            else if (userKey == null && (k.contains("user") || k.contains("name")
                    || k.contains("account") || k.contains("uid") || k.contains("phone")
                    || k.equals("id"))) userKey = e.getKey();
        }
        if (userKey == null) userKey = "username";
        if (passKey == null) passKey = "password";

        Map<String, String> extras = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (e.getKey().equals(userKey) || e.getKey().equals(passKey)) continue;
            extras.put(e.getKey(), e.getValue());
        }

        cfg.set(Config.K_URL, url);
        cfg.set(Config.K_METHOD, method);
        cfg.set(Config.K_USER_KEY, userKey);
        cfg.set(Config.K_PASS_KEY, passKey);
        cfg.set(Config.K_EXTRA, buildQuery(extras));
        if (cfg.get(Config.K_SSID, "").isEmpty()) {
            String ssid = NetHelper.currentSsid(this);
            if (!ssid.isEmpty()) cfg.set(Config.K_SSID, ssid);
        }

        String msg = "已设为登录接口：\n" + method + " " + shownUrl
                + "\n账号字段：" + userKey + "   密码字段：" + passKey
                + "\n附带参数：" + extras.size() + " 个"
                + "\n\n返回主界面，填学号密码后点【测试登录】。";
        if (auto) {
            tvInfo.setText("🤖 已自动识别到登录请求并保存配置：\n" + method + " " + shownUrl
                    + "\n字段：" + userKey + " / " + passKey + "，附带参数 " + extras.size() + " 个"
                    + "\n\n继续在页面里登录；成功后会自动返回主界面。");
        } else {
            tvInfo.setText("✅ " + msg);
            Toast.makeText(this, "已写入配置，返回APP填写账号密码", Toast.LENGTH_SHORT).show();
        }
        appliedUrl = url;
    }

    private static Map<String, String> parseQuery(String s) {
        Map<String, String> m = new LinkedHashMap<>();
        if (s == null || s.isEmpty()) return m;
        String[] pairs = s.split("&");
        for (String p : pairs) {
            int i = p.indexOf('=');
            String k, v;
            try {
                if (i < 0) {
                    k = java.net.URLDecoder.decode(p, "UTF-8");
                    v = "";
                } else {
                    k = java.net.URLDecoder.decode(p.substring(0, i), "UTF-8");
                    v = java.net.URLDecoder.decode(p.substring(i + 1), "UTF-8");
                }
            } catch (Throwable t) {
                continue;
            }
            if (!k.isEmpty() && !m.containsKey(k)) m.put(k, v);
        }
        return m;
    }
}
