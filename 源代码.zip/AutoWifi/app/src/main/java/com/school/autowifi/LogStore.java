package com.school.autowifi;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

/** 轻量日志：内存环形缓冲 + 追加写文件，便于把现场发给开发者排查 */
public class LogStore {

    private static final int MAX_MEM = 500;
    private static final long MAX_FILE = 300 * 1024L;
    private static final String FILE_NAME = "autowifi.log";

    private static final ArrayDeque<String> MEM = new ArrayDeque<>();
    private static Context app;

    public static void init(Context ctx) {
        app = ctx.getApplicationContext();
        try {
            File f = new File(app.getFilesDir(), FILE_NAME);
            if (f.exists() && f.length() > MAX_FILE) f.delete();
        } catch (Throwable ignored) { }
        add("APP", "启动，日志系统就绪");
    }

    public static void add(String tag, String msg) {
        String line;
        try {
            line = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.CHINA).format(new Date())
                    + " [" + tag + "] " + (msg == null ? "" : msg);
        } catch (Throwable t) {
            line = "[" + tag + "] " + msg;
        }
        synchronized (MEM) {
            MEM.addLast(line);
            while (MEM.size() > MAX_MEM) MEM.removeFirst();
        }
        if (app == null) return;
        try (FileOutputStream fos = new FileOutputStream(new File(app.getFilesDir(), FILE_NAME), true)) {
            fos.write((line + "\n").getBytes());
        } catch (Throwable ignored) { }
    }

    public static String dump(Context ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append("===== 校园网自动登录 日志 =====\n");
        sb.append("时间：").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA)
                .format(new Date())).append('\n');
        sb.append("版本：").append(Build0.versionName(ctx)).append('\n');
        sb.append("机型：").append(android.os.Build.MANUFACTURER).append(' ')
                .append(android.os.Build.MODEL).append(" / Android ")
                .append(android.os.Build.VERSION.RELEASE).append(" (SDK ")
                .append(android.os.Build.VERSION.SDK_INT).append(")\n");
        sb.append("当前 WiFi：").append(NetHelper.currentSsid(ctx)).append('\n');
        sb.append("===== 记录开始 =====\n");
        synchronized (MEM) {
            for (String l : MEM) sb.append(l).append('\n');
        }
        sb.append("===== 记录结束 =====\n");
        return sb.toString();
    }

    /** 取最近 n 行输出，供主界面常驻输出栏展示 */
    public static String tail(int lines) {
        synchronized (MEM) {
            int n = Math.min(lines, MEM.size());
            if (n == 0) return "（暂无输出）";
            ArrayDeque<String> d = new ArrayDeque<>();
            Iterator<String> it = MEM.descendingIterator();
            for (int i = 0; i < n && it.hasNext(); i++) d.addFirst(it.next());
            StringBuilder sb = new StringBuilder();
            for (String l : d) sb.append(l).append('\n');
            return sb.toString().trim();
        }
    }

    public static void clear(Context ctx) {
        synchronized (MEM) {
            MEM.clear();
        }
        try {
            File f = new File(ctx.getFilesDir(), FILE_NAME);
            if (f.exists()) f.delete();
        } catch (Throwable ignored) { }
    }

    /** 把日志写到「下载」目录（Android 10+ 免权限），失败返回 null */
    public static File saveToDownloads(Context ctx, String text) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                return null; // 走 MediaStore，见 MainActivity
            }
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "AutoWifi");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File f = new File(dir, "autowifi-log-"
                    + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.CHINA).format(new Date()) + ".txt");
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(text.getBytes());
            }
            return f;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 内部工具，避免与 android.os.Build 名字冲突 */
    static class Build0 {
        static String versionName(Context ctx) {
            try {
                return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName;
            } catch (Throwable t) {
                return "?";
            }
        }
    }
}
