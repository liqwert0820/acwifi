package com.school.autowifi;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 网页静默登录：用后台 WebView 打开认证页，注入脚本自动勾协议、填账号密码、点登录按钮。
 * 好处是不需要自己复刻门户的加密逻辑（sign / iv / RSA），页面自己的 JS 会算好再提交。
 */
public class WebLoginEngine {

    public interface Callback {
        void onResult(boolean ok, String detail);
    }

    public static void login(final Context ctx, final Config cfg, final Callback cb) {
        // 每次登录前重新探测一次认证页地址：门户地址里带 wlanuserip，重连后 IP 会变
        new Thread(() -> {
            String fresh = NetHelper.freshPortalUrl();
            String pageUrl = fresh.isEmpty() ? cfg.get(Config.K_URL, "").trim() : fresh;
            if (!pageUrl.isEmpty() && !pageUrl.equals(cfg.get(Config.K_URL, ""))) {
                cfg.set(Config.K_URL, pageUrl);
                LogStore.add("WEB", "刷新认证页地址：" + pageUrl);
            }
            if (pageUrl.isEmpty()) {
                cb.onResult(false, "登录地址为空");
                return;
            }
            Handler main = new Handler(Looper.getMainLooper());
            main.post(() -> doLoginOnMain(ctx, cfg, cb, pageUrl));
        }, "weblogin-prep").start();
    }

    private static void doLoginOnMain(final Context ctx, final Config cfg,
                                      final Callback cb, final String pageUrl) {
        {
            final Handler main = new Handler(Looper.getMainLooper());
            final AtomicBoolean done = new AtomicBoolean(false);
            final AtomicInteger checks = new AtomicInteger(0);
            final WebView[] holder = new WebView[1];
            final Runnable[] poller = new Runnable[1];
            // 认证提交后门户放行可能有延迟，首次校验前先等待配置的秒数
            final int delay = Math.max(3, cfg.getInt(Config.K_DELAY, 6));

            try {
                WebView wv = new WebView(ctx);
                holder[0] = wv;
                wv.setVisibility(View.GONE);
                if (ctx instanceof android.app.Activity) {
                    try {
                        ((android.app.Activity) ctx).addContentView(wv,
                                new ViewGroup.LayoutParams(1, 1));
                    } catch (Throwable ignored) { }
                }

                WebSettings s = wv.getSettings();
                s.setJavaScriptEnabled(true);
                s.setDomStorageEnabled(true);
                s.setDatabaseEnabled(true);
                s.setLoadsImagesAutomatically(false);
                s.setUserAgentString("Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 "
                        + "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
                try {
                    s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
                } catch (Throwable ignored) { }
                try {
                    CookieManager.getInstance().setAcceptCookie(true);
                } catch (Throwable ignored) { }

                wv.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onReceivedSslError(WebView view, SslErrorHandler handler,
                                                   android.net.http.SslError error) {
                        handler.proceed();
                    }

                    @Override
                    public void onPageStarted(WebView view, String url, Bitmap favicon) {
                        LogStore.add("WEB", "加载认证页 " + url);
                    }

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        LogStore.add("WEB", "页面加载完成 " + url);
                        // 分阶段注入：先勾协议，再填表点击，间隔重试以防表单是异步渲染
                        view.evaluateJavascript(script(cfg), v ->
                                LogStore.add("WEB", "注入#1 " + v));
                        main.postDelayed(() -> {
                            if (!done.get()) view.evaluateJavascript(script(cfg), v ->
                                    LogStore.add("WEB", "注入#2 " + v));
                        }, 1500);
                        main.postDelayed(() -> {
                            if (!done.get()) view.evaluateJavascript(script(cfg), v ->
                                    LogStore.add("WEB", "注入#3 " + v));
                        }, 4000);
                    }
                });

                wv.loadUrl(pageUrl);
                String family = PortalFamily.detect(pageUrl, null);
                LogStore.add("WEB", "开始网页静默登录 " + pageUrl + "（门户：" + family + "）");

                poller[0] = () -> {
                    if (done.get()) return;
                    if (NetHelper.isWifiValidated(ctx)) {
                        finish(done, cb, true, "网页登录成功，WiFi 已可联网");
                        destroy(holder);
                        return;
                    }
                    int n = checks.incrementAndGet();
                    if (n >= 6) {
                        finish(done, cb, false, "网页登录后仍未联网（等待并复查多轮后失败）");
                        destroy(holder);
                        return;
                    }
                    main.postDelayed(poller[0], 3500);
                };
                LogStore.add("WAIT", "网页登录已提交，等待 " + delay + " 秒再校验…");
                main.postDelayed(poller[0], delay * 1000L);

                main.postDelayed(() -> {
                    if (!done.get()) {
                        finish(done, cb, false, "网页登录超时");
                        destroy(holder);
                    }
                }, delay * 1000L + 30000);
            } catch (Throwable t) {
                LogStore.add("WEB", "WebView 初始化失败 " + t);
                finish(done, cb, false, "WebView 无法启动：" + t.getClass().getSimpleName());
                destroy(holder);
            }
        }
    }

    private static void finish(AtomicBoolean done, Callback cb, boolean ok, String detail) {
        if (!done.compareAndSet(false, true)) return;
        LogStore.add("WEB", (ok ? "成功 " : "失败 ") + detail);
        try {
            cb.onResult(ok, detail);
        } catch (Throwable ignored) { }
    }

    private static void destroy(WebView[] holder) {
        final WebView wv = holder[0];
        if (wv == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                wv.stopLoading();
                ViewGroup parent = (ViewGroup) wv.getParent();
                if (parent != null) parent.removeView(wv);
                wv.removeAllViews();
                wv.destroy();
            } catch (Throwable ignored) { }
            holder[0] = null;
        });
    }

    /** 自动勾协议、定位账号/密码框、填值、点登录 */
    private static String script(Config cfg) {
        String user = JSONObject.quote(cfg.get(Config.K_USER, ""));
        String pass = JSONObject.quote(cfg.get(Config.K_PASS, ""));
        return "(function(){try{"
                + "var U=" + user + ",P=" + pass + ";"
                + "function vis(e){try{var r=e.getBoundingClientRect();"
                + "return r.width>2&&r.height>2}catch(x){return true}}"
                + "function setv(e,v){try{var d=Object.getOwnPropertyDescriptor("
                + "e.constructor.prototype,'value');if(d&&d.set){d.set.call(e,v)}else{e.value=v}}"
                + "catch(x){e.value=v}"
                + "try{e.dispatchEvent(new Event('input',{bubbles:true}));"
                + "e.dispatchEvent(new Event('change',{bubbles:true}));"
                + "e.dispatchEvent(new Event('keyup',{bubbles:true}))}catch(x){}}"
                + "var cb=document.querySelectorAll('input[type=checkbox]');"
                + "for(var i=0;i<cb.length;i++){try{if(!cb[i].checked){cb[i].checked=true;"
                + "cb[i].dispatchEvent(new Event('change',{bubbles:true}));"
                + "cb[i].dispatchEvent(new Event('click',{bubbles:true}))}}catch(x){}}"
                + "var pw=null,ps=document.querySelectorAll('input[type=password]');"
                + "for(var i=0;i<ps.length;i++){if(vis(ps[i])){pw=ps[i];break}}"
                + "if(!pw&&ps.length)pw=ps[0];"
                + "if(!pw)return 'NO_PASSWORD_FIELD';"
                + "var f=pw.form,c=[];"
                + "if(f){c=f.querySelectorAll('input[type=text],input[type=tel],"
                + "input[type=number],input:not([type])')}"
                + "if(!c.length){c=document.querySelectorAll("
                + "'input[type=text],input[type=tel],input[type=number]')}"
                + "var un=null;"
                + "for(var i=0;i<c.length;i++){var e=c[i];if(!vis(e))continue;"
                + "var id=(e.name||'')+' '+(e.id||'');"
                + "if(/user|account|name|phone|tel|mobile|login|student|sid|no/i.test(id)){un=e;break}}"
                + "if(!un){for(var i=0;i<c.length;i++){if(vis(c[i])){un=c[i];break}}}"
                + "if(!un)return 'NO_ACCOUNT_FIELD';"
                + "setv(un,U);setv(pw,P);"
                + "var clicked=false,bs=document.querySelectorAll("
                + "'button,input[type=submit],input[type=button],a,div[onclick],span[onclick]');"
                + "for(var i=0;i<bs.length;i++){var t=(bs[i].innerText||bs[i].value||'').trim();"
                + "if(/^(登录|登 录|连接|认证|确定|上网|我要上网|登录上网|一键连接|连接网络|Login|Sign in|Connect|Go)/i.test(t))"
                + "{try{bs[i].click();clicked=true}catch(x){}break}}"
                + "if(!clicked&&f){try{if(f.requestSubmit){f.requestSubmit()}else{f.submit()}clicked=true}catch(x){}}"
                + "return 'FILLED:'+(un.name||un.id||'?')+'/'+(pw.name||pw.id||'?')+',click='+clicked;"
                + "}catch(e){return 'ERR:'+e}})()";
    }
}
